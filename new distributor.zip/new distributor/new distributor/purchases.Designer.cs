﻿namespace new_distributor
{
    partial class purchases
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbcompname = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtcpaid = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txtdamount = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtinvoice = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtnbill = new System.Windows.Forms.TextBox();
            this.txttquantity = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtdiscount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txttbill = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbpid = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtsaleid = new System.Windows.Forms.TextBox();
            this.txtbill = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbproname = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnsdadd = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtinvoiceno = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtuprice = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.lbrows = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(44, 379);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(910, 207);
            this.dataGridView1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.cbcompname);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.txtcpaid);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtdamount);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtinvoice);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtnbill);
            this.groupBox1.Controls.Add(this.txttquantity);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtdiscount);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txttbill);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(44, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(531, 270);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "purchases Main";
            // 
            // cbcompname
            // 
            this.cbcompname.FormattingEnabled = true;
            this.cbcompname.Location = new System.Drawing.Point(391, 67);
            this.cbcompname.Name = "cbcompname";
            this.cbcompname.Size = new System.Drawing.Size(104, 26);
            this.cbcompname.TabIndex = 63;
            this.cbcompname.SelectedIndexChanged += new System.EventHandler(this.cbcompname_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label17.Location = new System.Drawing.Point(257, 132);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(24, 20);
            this.label17.TabIndex = 62;
            this.label17.Text = "%";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Location = new System.Drawing.Point(303, 154);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(163, 86);
            this.groupBox3.TabIndex = 61;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Operation";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(81, 37);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(67, 32);
            this.button2.TabIndex = 1;
            this.button2.Text = "Delate";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(13, 37);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtcpaid
            // 
            this.txtcpaid.BackColor = System.Drawing.Color.White;
            this.txtcpaid.Location = new System.Drawing.Point(150, 193);
            this.txtcpaid.Name = "txtcpaid";
            this.txtcpaid.Size = new System.Drawing.Size(100, 26);
            this.txtcpaid.TabIndex = 55;
            this.txtcpaid.TextChanged += new System.EventHandler(this.txtcpaid_TextChanged);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(33, 196);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 23);
            this.label10.TabIndex = 54;
            this.label10.Text = "Cash paid:";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(33, 225);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 23);
            this.label6.TabIndex = 57;
            this.label6.Text = "Due Amount:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(391, 35);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(103, 26);
            this.dateTimePicker1.TabIndex = 60;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(33, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 23);
            this.label1.TabIndex = 44;
            this.label1.Text = "Invoice No:";
            // 
            // txtdamount
            // 
            this.txtdamount.BackColor = System.Drawing.Color.White;
            this.txtdamount.Location = new System.Drawing.Point(150, 225);
            this.txtdamount.Name = "txtdamount";
            this.txtdamount.Size = new System.Drawing.Size(100, 26);
            this.txtdamount.TabIndex = 56;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(265, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 23);
            this.label8.TabIndex = 59;
            this.label8.Text = "Company Name :";
            // 
            // txtinvoice
            // 
            this.txtinvoice.BackColor = System.Drawing.Color.White;
            this.txtinvoice.Location = new System.Drawing.Point(150, 37);
            this.txtinvoice.Name = "txtinvoice";
            this.txtinvoice.Size = new System.Drawing.Size(100, 26);
            this.txtinvoice.TabIndex = 49;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(265, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 23);
            this.label7.TabIndex = 58;
            this.label7.Text = "Purchase Date:";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(33, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 23);
            this.label3.TabIndex = 46;
            this.label3.Text = "Total Quantity:";
            // 
            // txtnbill
            // 
            this.txtnbill.BackColor = System.Drawing.Color.White;
            this.txtnbill.Location = new System.Drawing.Point(150, 165);
            this.txtnbill.Name = "txtnbill";
            this.txtnbill.Size = new System.Drawing.Size(100, 26);
            this.txtnbill.TabIndex = 53;
            // 
            // txttquantity
            // 
            this.txttquantity.BackColor = System.Drawing.Color.White;
            this.txttquantity.Location = new System.Drawing.Point(150, 69);
            this.txttquantity.Name = "txttquantity";
            this.txttquantity.Size = new System.Drawing.Size(100, 26);
            this.txttquantity.TabIndex = 50;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(33, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 23);
            this.label4.TabIndex = 47;
            this.label4.Text = " Net Bill:";
            // 
            // txtdiscount
            // 
            this.txtdiscount.BackColor = System.Drawing.Color.White;
            this.txtdiscount.Location = new System.Drawing.Point(150, 133);
            this.txtdiscount.Name = "txtdiscount";
            this.txtdiscount.Size = new System.Drawing.Size(100, 26);
            this.txtdiscount.TabIndex = 52;
            this.txtdiscount.TextChanged += new System.EventHandler(this.txtdiscount_TextChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(33, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 23);
            this.label2.TabIndex = 45;
            this.label2.Text = "Discount:";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(33, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 23);
            this.label5.TabIndex = 48;
            this.label5.Text = "Total Bill:";
            // 
            // txttbill
            // 
            this.txttbill.BackColor = System.Drawing.Color.White;
            this.txttbill.Location = new System.Drawing.Point(150, 101);
            this.txttbill.Name = "txttbill";
            this.txttbill.Size = new System.Drawing.Size(100, 26);
            this.txttbill.TabIndex = 51;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.lbpid);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.txtsaleid);
            this.groupBox2.Controls.Add(this.txtbill);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.cbproname);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.btnsdadd);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtinvoiceno);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtquantity);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.txtuprice);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(581, 65);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(373, 270);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Purchases detail";
            // 
            // lbpid
            // 
            this.lbpid.AutoSize = true;
            this.lbpid.BackColor = System.Drawing.Color.White;
            this.lbpid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbpid.ForeColor = System.Drawing.Color.DarkRed;
            this.lbpid.Location = new System.Drawing.Point(302, 91);
            this.lbpid.Name = "lbpid";
            this.lbpid.Size = new System.Drawing.Size(2, 20);
            this.lbpid.TabIndex = 54;
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(47, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(120, 23);
            this.label15.TabIndex = 76;
            this.label15.Text = "purchase ID:";
            // 
            // txtsaleid
            // 
            this.txtsaleid.BackColor = System.Drawing.Color.White;
            this.txtsaleid.Location = new System.Drawing.Point(183, 20);
            this.txtsaleid.Name = "txtsaleid";
            this.txtsaleid.Size = new System.Drawing.Size(112, 26);
            this.txtsaleid.TabIndex = 75;
            // 
            // txtbill
            // 
            this.txtbill.Location = new System.Drawing.Point(183, 192);
            this.txtbill.Name = "txtbill";
            this.txtbill.Size = new System.Drawing.Size(112, 26);
            this.txtbill.TabIndex = 74;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(47, 93);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 23);
            this.label12.TabIndex = 69;
            this.label12.Text = "Product Nmae:";
            // 
            // cbproname
            // 
            this.cbproname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbproname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbproname.BackColor = System.Drawing.Color.White;
            this.cbproname.FormattingEnabled = true;
            this.cbproname.Location = new System.Drawing.Point(183, 87);
            this.cbproname.Name = "cbproname";
            this.cbproname.Size = new System.Drawing.Size(112, 26);
            this.cbproname.TabIndex = 72;
            this.cbproname.SelectedIndexChanged += new System.EventHandler(this.cbproname_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(47, 195);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 18);
            this.label9.TabIndex = 73;
            this.label9.Text = " Bill";
            // 
            // btnsdadd
            // 
            this.btnsdadd.BackColor = System.Drawing.Color.White;
            this.btnsdadd.Location = new System.Drawing.Point(110, 227);
            this.btnsdadd.Name = "btnsdadd";
            this.btnsdadd.Size = new System.Drawing.Size(211, 36);
            this.btnsdadd.TabIndex = 71;
            this.btnsdadd.Text = "Add To Cart";
            this.btnsdadd.UseVisualStyleBackColor = false;
            this.btnsdadd.Click += new System.EventHandler(this.btnsdadd_Click);
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(47, 59);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 23);
            this.label11.TabIndex = 63;
            this.label11.Text = "Invoice No:";
            // 
            // txtinvoiceno
            // 
            this.txtinvoiceno.BackColor = System.Drawing.Color.White;
            this.txtinvoiceno.Location = new System.Drawing.Point(183, 54);
            this.txtinvoiceno.Name = "txtinvoiceno";
            this.txtinvoiceno.Size = new System.Drawing.Size(112, 26);
            this.txtinvoiceno.TabIndex = 66;
            this.txtinvoiceno.TextChanged += new System.EventHandler(this.txtinvoiceno_TextChanged);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(47, 129);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 23);
            this.label13.TabIndex = 64;
            this.label13.Text = "Quantity:";
            // 
            // txtquantity
            // 
            this.txtquantity.BackColor = System.Drawing.Color.White;
            this.txtquantity.Location = new System.Drawing.Point(183, 124);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(112, 26);
            this.txtquantity.TabIndex = 67;
            this.txtquantity.TextChanged += new System.EventHandler(this.txtquantity_TextChanged);
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(47, 163);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(93, 23);
            this.label16.TabIndex = 65;
            this.label16.Text = "Unit Price:";
            // 
            // txtuprice
            // 
            this.txtuprice.BackColor = System.Drawing.Color.White;
            this.txtuprice.Location = new System.Drawing.Point(183, 158);
            this.txtuprice.Name = "txtuprice";
            this.txtuprice.Size = new System.Drawing.Size(112, 26);
            this.txtuprice.TabIndex = 68;
            this.txtuprice.TextChanged += new System.EventHandler(this.txtuprice_TextChanged);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.BackgroundImage = global::new_distributor.Properties.Resources._1456931289_Cancel_Icon;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Location = new System.Drawing.Point(883, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(71, 47);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(110, 344);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(259, 22);
            this.label14.TabIndex = 3;
            this.label14.Text = "Number of Product Added To Cart :";
            // 
            // lbrows
            // 
            this.lbrows.AutoSize = true;
            this.lbrows.BackColor = System.Drawing.Color.White;
            this.lbrows.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbrows.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbrows.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbrows.Location = new System.Drawing.Point(398, 344);
            this.lbrows.Name = "lbrows";
            this.lbrows.Size = new System.Drawing.Size(21, 22);
            this.lbrows.TabIndex = 4;
            this.lbrows.Text = "0";
            // 
            // purchases
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 598);
            this.Controls.Add(this.lbrows);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "purchases";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "purchases";
            this.Load += new System.EventHandler(this.purchases_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtsaleid;
        private System.Windows.Forms.TextBox txtbill;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbproname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnsdadd;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtinvoiceno;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtuprice;
        private System.Windows.Forms.ComboBox cbcompname;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtcpaid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtdamount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtinvoice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtnbill;
        private System.Windows.Forms.TextBox txttquantity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdiscount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txttbill;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbrows;
        private System.Windows.Forms.Label lbpid;
    }
}