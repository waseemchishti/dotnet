﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace new_distributor
{
    public partial class splash : Form
    {
        public splash()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void saplaish_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
        int cout = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            cout += 1;
            label3.Text = cout.ToString();
            if (cout == 20)
            {
                mdi obj = new mdi();
                obj.Show();
                this.Hide();
                timer1.Stop();

            }


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
