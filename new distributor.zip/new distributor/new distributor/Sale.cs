﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;
using System.Data.SqlClient;

namespace new_distributor
{
    public partial class Sale : Form
    {
        public Sale()
        {
            InitializeComponent();
        }
        double tbill;
        double bill;
        double ttbil;
        int quantity;
        int tquantity;
        int ttquantity;
       
        DataTable dt = new DataTable();
        DataRow dr;
        BAL bl = new BAL();
        SqlConnection con = new SqlConnection(@"Data Source=desktop-lc4ovj7\sqlexpress;Initial Catalog=awan_distributor;Integrated Security=True");
        private void Sale_Load(object sender, EventArgs e)
        {
            saleamainname();
            get_p_name();
            dt.Columns.Add("Detail Id");
            dt.Columns.Add("INvoice#");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("UNit PRice");
            dt.Columns.Add("Product ID");
            dt.Columns.Add("Bill");
        }

        private void saleamainname()
        {
            if ( bl.salesmanname().Rows.Count > 0)
            {

                for (int i = 0; i <  bl.salesmanname().Rows.Count; i++)
                {
                   cbsmname.Items.Add( bl.salesmanname().Rows[i].ItemArray[0].ToString());
                }
            }

        }
        private void get_p_name()
        {

            DataTable tb = new DataTable();
            
            tb = bl.p_search_name();
            if (tb.Rows.Count > 0)
            {
                 
                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    cbproname.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                }
            }

        }


        private void btnsdadd_Click(object sender, EventArgs e)
        {

            bill = Convert.ToDouble(txtbill.Text);
            tbill = tbill + bill;
            txttbill.Text = tbill.ToString();
               

            quantity = Convert.ToInt32(txtquantity.Text);
            tquantity += quantity;
            txttquantity.Text = tquantity.ToString();


            dr = dt.NewRow();
            dr["Detail Id"] = txtsaleid.Text;
            dr["INvoice#"] = txtinvoiceno.Text;
            dr["Quantity"] = txtquantity.Text;
            dr["UNit PRice"] = txtuprice.Text;
            dr["Product ID"] = lbpid.Text;
            dr["Bill"] = txtbill.Text;
            dt.Rows.Add(dr);
            dataGridView1.DataSource = dt;
            lbrows.Text = dt.Rows.Count.ToString();
            txtsaleid.Text = "";
           // txtinvoiceno.Text = "";
            txtquantity.Text = "";
            txtuprice.Text = "";
            cbproname.Text = "";
            txtbill.Text = "";

        }

        private void cbproname_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id;
            string stkquan;
            string stkprice;
            id = bl.get_p_id(cbproname.Text).Rows[0].ItemArray[0].ToString();
            if (bl.get_p_id(cbproname.Text).Rows.Count > 0)
            {
                lbpid.Text = id;

            }


            if (bl.stokqpsearch(id).Rows.Count > 0)
            {
                stkquan = bl.stokqpsearch(id).Rows[0].ItemArray[2].ToString();
              stkprice=  bl.stokqpsearch(id).Rows[0].ItemArray[3].ToString();
                lbquantity.Text = stkquan;
                txtuprice.Text = stkprice;
                
            }
          
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

     
        private void txtdiscount_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcpaid_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtinvoiceno_TextChanged(object sender, EventArgs e)
        {
            if (txtinvoiceno.Text == "")
            {

            }
            else
            {

                if (txtinvoiceno.Text == "")
                {
                    return;
                }

                txtinvoice.Text = txtinvoiceno.Text;

            }
        }

        private void txtuprice_TextChanged(object sender, EventArgs e)
        {

           
            if (txtuprice.Text == "")
            {

            }
            else
            {
                if (txtuprice.Text == "")
                {
                    return;
                }
                double q = Convert.ToDouble(txtquantity.Text);
                double p = Convert.ToDouble(txtuprice.Text);
                double res = q * p;
                txtbill.Text = res.ToString();
            }
        }

        private void txtquantity_TextChanged_1(object sender, EventArgs e)
        {
            if (txtquantity.Text == "")
            {

            }
            else
            {
                if (txtquantity.Text == "")
                {
                    return;
                }
                else
                {
                   int tquantity = Convert.ToInt32(lbquantity.Text);
                    int txtquan = Convert.ToInt32(txtquantity.Text);
                    if (txtquan > tquantity)
                    {
                        MessageBox.Show("Enlisted quantity not Availabel");
                        txtquantity.Text = "";
                        txtquantity.Focus();

                    }
                }
               
  
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {


            SqlTransaction trans;
            con.Open();
            trans = con.BeginTransaction();
           
            try
            {
                if (dataGridView1.Rows.Count <= 0)
                {
                    MessageBox.Show("First Add product to cart");
                }

                
                    SqlCommand cmd = new SqlCommand("smaininsert", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@inv", txtinvoice.Text);
                    cmd.Parameters.AddWithValue("@quan", txttquantity.Text);
                    cmd.Parameters.AddWithValue("@bill", txttbill.Text);
                    cmd.Parameters.AddWithValue("@dis", txtdiscount.Text);
                    cmd.Parameters.AddWithValue("@netbil", txtnbill.Text);
                    cmd.Parameters.AddWithValue("@cpaid", txtcpaid.Text);
                    cmd.Parameters.AddWithValue("@due", txtdamount.Text);
                    cmd.Parameters.AddWithValue("@date", dateTimePicker1.Text);
                    cmd.Parameters.AddWithValue("@smname",cbsmname.Text);
                    cmd.Transaction = trans;
                    cmd.ExecuteNonQuery();

                //sale main due update

                    SqlCommand scmd = new SqlCommand("saldueupdate", con);
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@sname",cbsmname.Text);
                    scmd.Parameters.AddWithValue("@due", txtdamount.Text);
                    scmd.Transaction = trans;
                    scmd.ExecuteNonQuery();

                    for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                    {
                        //purchase insert
                        SqlCommand cmdd = new SqlCommand("sdetailinsert", con);
                        cmdd.CommandType = CommandType.StoredProcedure;
                        cmdd.Parameters.AddWithValue("@did",  dataGridView1.Rows[i].Cells["Detail Id"].Value.ToString());
                        cmdd.Parameters.AddWithValue("@inv",dataGridView1.Rows[i].Cells["INvoice#"].Value.ToString());
                        cmdd.Parameters.AddWithValue("@quan", dataGridView1.Rows[i].Cells["Quantity"].Value.ToString());
                        cmdd.Parameters.AddWithValue("@uprice",dataGridView1.Rows[i].Cells["UNit PRice"].Value.ToString());
                        cmdd.Parameters.AddWithValue("@pid", dataGridView1.Rows[i].Cells["Product ID"].Value.ToString());
                        cmdd.Parameters.AddWithValue("@bill", dataGridView1.Rows[i].Cells["Bill"].Value.ToString());
                        cmdd.Transaction = trans;
                        cmdd.ExecuteNonQuery();

                        //quantity update...

                        string quan = dataGridView1.Rows[i].Cells["Quantity"].Value.ToString();
                       int rs = Convert.ToInt32(quan);
                        string pnam = dataGridView1.Rows[i].Cells["Product ID"].Value.ToString();

                        SqlCommand comand = new SqlCommand("stockquantityupdate", con);
                        comand.CommandType = CommandType.StoredProcedure;
                        comand.Parameters.AddWithValue("@quan", rs);
                        comand.Parameters.AddWithValue("@pid", pnam);
                        comand.Transaction = trans;
                        comand.ExecuteNonQuery();


                    }
                    trans.Commit();
                //.....................
                    txtinvoice.Text = "";
                    txttquantity.Text = "";
                    txttbill.Text = "";
                    txtdiscount.Text = "";
                    txtnbill.Text = "";
                    txtcpaid.Text = "";
                    txtdamount.Text = "";
                    txtsaleid.Text = "";

                    dataGridView1.DataSource = null;
                }
            
            catch (Exception ex)
            {

                trans.Rollback();
                 throw ex;
            }
            con.Close();
        }

        private void txtinvoiceno_TextChanged_1(object sender, EventArgs e)
        {
            if (txtinvoiceno.Text == "")
            {

            }
            else
            {

                if (txtinvoiceno.Text == "")
                {
                    return;
                }

                txtinvoice.Text = txtinvoiceno.Text;

            }
        }

        private void txtquantity_TextChanged(object sender, EventArgs e)
        {

            if (txtquantity.Text == "")
            {

            }
            else
            {
                if (txtquantity.Text == "")
                {
                    return;
                }
                    int tquantity = Convert.ToInt32(lbquantity.Text);
                    int txtquan = Convert.ToInt32(txtquantity.Text);


                    if (txtquan > tquantity)
                    {
                        MessageBox.Show("Enlisted quantity not Availabel");
                        txtquantity.Text = "";
                        txtquantity.Focus();
                        return;
                    }

                    double q = Convert.ToDouble(txtquantity.Text);
                    double p = Convert.ToDouble(txtuprice.Text);
                    double res = q * p;
                    txtbill.Text = res.ToString();
    
            }
        }
        
        private void txtuprice_TextChanged_1(object sender, EventArgs e)
        {
           

         }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtdiscount_TextChanged_1(object sender, EventArgs e)
        {
            if (txtdiscount.Text == "")
            {

            }
            else
            {

                if (txtdiscount.Text == "")
                {
                    return;
                }
                double dis = Convert.ToDouble(txtdiscount.Text);
                double tbill = Convert.ToDouble(txttbill.Text);
                double res = (dis / 100) * tbill;
                txtnbill.Text = (tbill - res).ToString();
                
            }
        }

        private void txtcpaid_TextChanged_1(object sender, EventArgs e)
        {
            if (txtcpaid.Text == "")
            {
               
            }
            else
            {

                if (txtcpaid.Text == "")
                {
                    return;
                }

                double nbil = Convert.ToDouble(txtnbill.Text);
                double cashp = Convert.ToDouble(txtcpaid.Text);
                double res = (nbil - cashp);
                txtdamount.Text = res.ToString();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bl.smain_delete(txtinvoice.Text);
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            
           int tqu=Convert.ToInt32 (txttquantity.Text);
           double tttbill = Convert.ToDouble(txttbill.Text);
           
               int dgquan = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["Quantity"].Value);
               double dgbill = Convert.ToDouble(dataGridView1.SelectedRows[0].Cells["Bill"].Value);
               // MessageBox.Show(dgquan.ToString() +"\n"+dgbill.ToString());
               ttquantity=(tqu - dgquan);
               txttquantity.Text = ttquantity.ToString();
               tquantity = ttquantity;
              //double bilres = (ttbill - dgbill);
               ttbil = (tttbill - dgbill);
               txttbill.Text =ttbil.ToString();
               tbill = ttbil;
               dataGridView1.Rows.RemoveAt(0);

              lbrows.Text= dataGridView1.Rows.Count.ToString();
               
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
            //dataGridView2.DataSource = dt;



        }

        

        private void button4_Click(object sender, EventArgs e)
        {
           
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void txtinvoice_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtnbill_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void lbquantity_Click(object sender, EventArgs e)
        {

        }

        private void cbsmname_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lbpid_Click(object sender, EventArgs e)
        {

        }

        private void txtbill_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
       
    }
}
