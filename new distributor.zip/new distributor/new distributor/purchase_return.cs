﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using new_distributor.b_l;

namespace new_distributor
{
    public partial class purchase_return : Form
    {
        public purchase_return()
        {
            InitializeComponent();
        }
        double tbill;
        double bill;
        // double ttbil;
        int quantity;
        int tquantity;
        DataTable dt = new DataTable();
        DataRow dr;
        BAL bl = new BAL();
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-LC4OVJ7\SQLEXPRESS;Initial Catalog=awan_distributor;Integrated Security=True");
        private void purchase_return_Load(object sender, EventArgs e)
        {
            get_p_name();
            compny_name();
            dt.Columns.Add("Invoice_no");
            dt.Columns.Add("Return_id");
            dt.Columns.Add("Product_id");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Unit_Price");
            dt.Columns.Add("Bill");
            dt.Columns.Add("discount_description");
            

        }
        private void get_p_name()
        {


            dt = bl.p_search_name();
            if (dt.Rows.Count > 0)
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    detail_combo.Items.Add(dt.Rows[i].ItemArray[0].ToString());
                }
            }

        }
        private void compny_name()
        {
            bl.compnyname();
            for (int i = 0; i < bl.compnyname().Rows.Count; i++)
            {
                comboBox3.Items.Add(bl.compnyname().Rows[i].ItemArray[0].ToString());
            }
        }


       
        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        int i = 0;
        private void button4_Click(object sender, EventArgs e)
        {


            SqlTransaction trans;
            con.Open();
            trans = con.BeginTransaction();

            try
            {
                if (dataGridView1.Rows.Count <= 0)
                {
                    MessageBox.Show("First Add product to cart");
                }
               


                SqlCommand cmd = new SqlCommand("insert_purchase_retun_main", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(" @id", main_return_id.Text);
                cmd.Parameters.AddWithValue("@invoice", main_invoice.Text);
                cmd.Parameters.AddWithValue("@quantity", main_quantity.Text);
                cmd.Parameters.AddWithValue("@total_bill", main_total_bill.Text);
                cmd.Parameters.AddWithValue("@net_bill", main_bill.Text);
                cmd.Parameters.AddWithValue("@discount", main_discount.Text);
                cmd.Parameters.AddWithValue("@paid", main_cash.Text);
                cmd.Parameters.AddWithValue("@due", main_due.Text);
                cmd.Parameters.AddWithValue("@c_id", company_id.Text);
                cmd.Parameters.AddWithValue("@date", dateTimePicker2.Text);
                cmd.Parameters.AddWithValue("@c_name", comboBox3.Text);
                cmd.Transaction = trans;
                cmd.ExecuteNonQuery();

                //sale main due update



                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {

                    //purchase insert
                    SqlCommand cmdd = new SqlCommand("purchase_return_detail_insert", con);
                    cmdd.CommandType = CommandType.StoredProcedure;
                    cmdd.Parameters.AddWithValue("@p_id", dataGridView1.Rows[i].Cells["Return_id"].Value.ToString());
    
                    cmdd.Parameters.AddWithValue("@pid", dataGridView1.Rows[i].Cells["Product_id"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@invoice", dataGridView1.Rows[i].Cells["Invoice_no"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@quantity", dataGridView1.Rows[i].Cells["Quantity"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@up", dataGridView1.Rows[i].Cells["Unit_Price"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@bill", dataGridView1.Rows[i].Cells["Bill"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@disc", dataGridView1.Rows[i].Cells["discount_description"].Value.ToString());


                    cmdd.Transaction = trans;
                    cmdd.ExecuteNonQuery();

                    //quantity update...

                    string quan = dataGridView1.Rows[i].Cells["Quantity"].Value.ToString();
                    //int rs = Convert.ToInt32(quan);
                    string pnam = dataGridView1.Rows[i].Cells["Product_id"].Value.ToString();

                    SqlCommand comand = new SqlCommand("stock_quantity_update", con);
                    comand.CommandType = CommandType.StoredProcedure;
                    comand.Parameters.AddWithValue("@quantity", quan);
                    comand.Parameters.AddWithValue("@id", pnam);
                    comand.Transaction = trans;
                    comand.ExecuteNonQuery();

                }
                //company _due update..................


                SqlCommand scomand = new SqlCommand("company_due_update", con);
                scomand.CommandType = CommandType.StoredProcedure;
                scomand.Parameters.AddWithValue("@id", company_id.Text);
                scomand.Parameters.AddWithValue("@due", main_due.Text);
                scomand.Transaction = trans;
                scomand.ExecuteNonQuery();

                trans.Commit();
                //.....................
                main_return_id.Text = "";
               main_invoice.Text = "";
                main_quantity.Text = "";
                main_discount.Text = "";
                main_bill.Text = "";
                main_cash.Text = "";
                main_due.Text = "";
                main_total_bill.Text = "";

                dataGridView1.DataSource = null;


                con.Close();
            }

            catch (Exception ex)
            {

                trans.Rollback();
                throw ex;
            }





        //    for (int i = 0; i < 10; i++)
        //    {
               
        //        textBox4.Text = a.ToString();

               
        //    }

        //    MessageBox.Show(textBox4.Text + textBox6.Text);

        //    textBox4.Text = "";
        //    a += 1;
            
            
        //    //MessageBox.Show(textBox4.Text+textBox6.Text);
        //    //int i = 1;
           
        }

        private void textBox1_ModifiedChanged(object sender, EventArgs e)
        {

        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {

        }
        int a;
        private void button4_Enter(object sender, EventArgs e)
        {

            
           
           
           
        }
        //public void purchase_quantity_price(string invoice, string id, string pid)
        //{
        //    DataTable dt = new DataTable();
        //    dt = bl.purchase_quantity_price(dinvoice);

        //}
        private void product_idd_Click(object sender, EventArgs e)

        {


        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id;
            string return_quan;
            string return_unit_price;
            id = bl.get_p_id(detail_combo.Text).Rows[0].ItemArray[0].ToString();
            if (bl.get_p_id(detail_combo.Text).Rows.Count > 0)
            {
                product_id.Text = id;

            }
            string quan = bl.purchase_quantity_price(detail_id.Text).Rows[0].ItemArray[3].ToString();
            string up = bl.purchase_quantity_price(detail_id.Text).Rows[0].ItemArray[4].ToString();
            if ( bl.purchase_quantity_price(detail_id.Text).Rows.Count > 0)
            {
                detail_quantity_check.Text = quan;

            }
            if( bl.purchase_quantity_price(detail_id.Text).Rows.Count > 0)
            {
                detail_unitprice.Text = up;

            }
             
        }

        private void detail_id_TextChanged(object sender, EventArgs e)
        {
            main_return_id.Text = detail_id.Text;
        }

        private void product_id_TabIndexChanged(object sender, EventArgs e)
        {
           
        }

        ////private void product_id_TextChanged(object sender, EventArgs e)
        ////{

           
           

        ////    //if (bl.purchase_return_did(product_id.Text, dinvoice.Text).Rows.Count > 0)
        ////    //{

        ////    //    did.Text = bl.purchase_return_did(product_id.Text, dinvoice.Text).Rows[0].ItemArray[0].ToString();

        ////    //}
        ////}

        private void Check_Click(object sender, EventArgs e)
        {
            //tabPage3.Show();
            purchase_return_detail_check pr = new purchase_return_detail_check();
            pr.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            bill = Convert.ToDouble(detail_bill.Text);
            tbill = tbill + bill;
            main_bill.Text = tbill.ToString();


            quantity = Convert.ToInt32(detail_quantity.Text);
            tquantity += quantity;
            main_quantity.Text = tquantity.ToString();

            dr = dt.NewRow();
            dr["Invoice_no"] = detail_invoice.Text.ToString();
            dr["Return_id"] = detail_id.Text.ToString();
            dr["Product_id"] = product_id.Text.ToString();
            dr["Quantity"] = detail_quantity.Text.ToString();
            dr["Unit_Price"] = detail_unitprice.Text.ToString();
            dr["Bill"] = detail_bill.Text.ToString();

            if (detail_check_discount.Visible=true)
            {
                dr["Discount_Description"] = detail_check_discount;
            }

            dt.Rows.Add(dr);
            dataGridView1.DataSource = dt;

        }
       
   //public DataTable purchase_quantity(string invoice, string did, string pid)
   //     {
   //         DataTable dt = new DataTable();
   //         dt = bl.purchase_quantity_price(detail_invoice.Text, detail_id.Text, product_id.Text);
   //         return dt;

         
   //     }
        private void product_id_TextChanged_1(object sender, EventArgs e)
        {
         
            //dt=purchase_quantity(
            //if (dt.Rows.Count > 0)
            //{
            //    detail_quantity_check.Text = dt.Rows[0].ItemArray[0].ToString();
            //    //d_unitprice.Text = dt.Rows[0].ItemArray[].ToString();
            //}
        }

        private void detail_quantity_check_Click(object sender, EventArgs e)
        {

        }

        private void detail_quantity_TextChanged(object sender, EventArgs e)
        {
            if (detail_quantity.Text == "")
            {

            }
            else
            {
                main_quantity.Text = detail_quantity.Text;
                if (detail_quantity.Text == "")
                {
                    return;
                }

                int cquantity = Convert.ToInt32(detail_quantity_check.Text);
                int dquantity = Convert.ToInt32(detail_quantity.Text);


                if (dquantity > cquantity)
                {
                    MessageBox.Show("Enlisted quantity not Availabel");
                    detail_quantity.Text = "";
                    detail_quantity.Focus();
                    return;
                }

                double q = Convert.ToDouble(detail_quantity.Text);
                double p = Convert.ToDouble(detail_unitprice.Text);
                double res = q * p;
                detail_bill.Text = res.ToString();
            }
        }
        private void detail_unitprice_TextChanged(object sender, EventArgs e)
        {

        }

        private void detail_bill_TextChanged(object sender, EventArgs e)
        {
              main_total_bill.Text=detail_bill.Text;
        
        }

        private void detail_invoice_TextChanged(object sender, EventArgs e)
        {
            //string a = Convert.ToString(detail_invoice.Text);
            main_invoice.Text = detail_invoice.Text;
        }

        private void main_invoice_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id;
            id = bl.get_com_id(comboBox3.Text).Rows[0].ItemArray[0].ToString();
            company_id.Text = id; 
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            if (main_cash.Text == "")
            {

            }
            else
            {

                if (main_cash.Text == "")
                {
                    return;
                }

                double nbil = Convert.ToDouble(main_bill.Text);
                double cashp = Convert.ToDouble(main_cash.Text);
                double res = (nbil - cashp);
                main_due.Text = res.ToString();

            }
        }

        private void main_discount_TextChanged(object sender, EventArgs e)
        {
            if (main_discount.Text == "")
            {

            }
            else
            {

                if (main_discount.Text == "")
                {
                    return;
                }

                double dis = Convert.ToDouble(main_discount.Text);
                double tbill = Convert.ToDouble(main_total_bill.Text);

                double res = (dis / 100) * tbill;
                main_bill.Text = (tbill - res).ToString();}
//if (main_discount.Text == "")
            //{

            //}
            //else
            //{

            //    if (main_discount.Text == "")
            //    {
            //        return;
            //    }

            //    double dis = Convert.ToDouble(main_discount.Text);
            //    double tbill = Convert.ToDouble(main_total_bill.Text);

            //    double res = (dis / 100) * tbill;
            //    main_bill.Text = (tbill - res).ToString();

            //}
        }

        private void main_quantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void main_total_bill_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            main_discount.Text = bl.check_discount(detail_invoice.Text).Rows[0].ItemArray[0].ToString();

            detail_check_discount.Visible = true;
        }

        private void main_total_bill_TextChanged_1(object sender, EventArgs e)
        {

            if (main_discount.Text == "")
            {

            }
            else
            {

                if (main_discount.Text == "")
                {
                    return;
                }
                double dis = Convert.ToDouble(main_discount.Text);
                double tbill = Convert.ToDouble(main_total_bill.Text);
                double res = (dis / 100) * tbill;
                main_bill.Text = (tbill - res).ToString();

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
            bl.pdetail_search(p_i_search.Text);
        }

        private void company_id_TextChanged(object sender, EventArgs e)
        {

        }
        
       
    }
}
