﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Threading;
using new_distributor.b_l;


namespace new_distributor
{
    public partial class Login : Form
    {
        public Login()
        {

            Thread t = new Thread(new ThreadStart(SplashStart));
            t.Start();
            Thread.Sleep(5000);
            InitializeComponent();
            t.Abort();
        }

        public void SplashStart()
        {

            Application.Run(new Form2());
        }
      
        BAL bl = new BAL();
        SpeechSynthesizer ss = new SpeechSynthesizer();
        PromptBuilder pb = new PromptBuilder();
        SpeechRecognitionEngine sre = new SpeechRecognitionEngine();
        mdi obj = new mdi();
        private void log_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = bl.login_status(user_name.Text, passward.Text, textBox2.Text);

            {

                if (dt.Rows.Count > 0 & textBox2.Text==3.ToString())
                {

                    login_status();
                    obj.Login_employee();

                }

              
            else  if (dt.Rows.Count>0 & textBox2.Text==1.ToString())
                {

                    login_status();



                }
                



               else if (dt.Rows.Count>0 & textBox2.Text==2.ToString())
                {

                    login_status();
                    obj.Login_local();



                }



                else
                {

                    MessageBox.Show("Wrong User Name or Password","Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    user_name.Clear();
                    user_name.Focus();
                    passward.Clear();
                }
                //if (radioButton1.Checked == true)
                //{

                //    obj.Show();
                //}

            }
        }
        public void login_status()
        {


            pb.ClearContent();
            pb.AppendText(textBox1.Text);


            ss.Speak(pb);    
          //  MessageBox.Show("Welcome To Awan Enterprises", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.None);
            obj.Show();
            this.Hide();
           
           
          
        }
        private void cancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        
        {
            MessageBox.Show("Plese Enter Code For Registration");
            textBox3.Visible = true;
            textBox3.Focus();
            button1.Visible = false;
           
           
           
        }

        private void user_name_TextChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
          dt=  bl.login_acces_get(user_name.Text);
          if (dt.Rows.Count > 0)
          {
              textBox2.Text = dt.Rows[0].ItemArray[0].ToString();
          }
          else
          {
              return;
          }

        }
        
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

            user_registration ur = new user_registration();
            if (textBox3.Text == "awan123")
            {

                
                ur.Show();
                this.Hide();
            }

            else
            {
                return;
            }
            

        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

      
      
    }
}
