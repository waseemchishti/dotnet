﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using Webcameraa;

namespace new_distributor
{
    public partial class mdi : Form
    {
        public mdi()
        {
            InitializeComponent();
        }
        //to oprn category form
        private void cATEGORYToolStripMenuItem_Click(object sender, EventArgs e)
        {

            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "category")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                category ctg = new category();
                ctg.MdiParent = this;
                ctg.Show();
            }

        }
        //to open product form
        private void pRODUCTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "product")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                product pr = new product ();
                pr.MdiParent = this;
                pr.Show();
            }
        }

        private void companyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "company")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                company co = new company();
                co.MdiParent = this;
                co.Show();
            }
            
        }

        private void salesmanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "salesman")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                salesman obj = new salesman();
                obj.MdiParent = this;
                obj.Show();
            }
            
        }

        private void purchaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //int i = 0;
            //foreach (Form frm in Application.OpenForms)
            //{
            //    if (frm.GetType().Name == "purchases")
            //    {
            //        i = 1;
            //        return;
            //    }
            //}
            //if (i == 0)
            //{
            //    purchases obj = new purchases();
            //   obj.MdiParent = this;
            //   obj.Show();
            //} 
           
        }

        private void mdi_Load(object sender, EventArgs e)
        {
            timer2.Start();
            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "home")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                home h = new home();
                h.MdiParent = this;
                h.Show();
            }
        }
        // login...
        public void Login_employee(){
        
           
            mdi f = new mdi();
            catproToolStripMenuItem.Enabled = false;
        }
        public void Login_local()
        {


            mdi f = new mdi();
            accountsToolStripMenuItem.Enabled = false;
        }
        //stock tool strip.............
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "stock")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                stock st = new stock();
                st.MdiParent = this;
                st.Show();
            }
           
        }

        private void purchasemainToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void catproToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void mdi_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void saleToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void dueUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void dueUpdateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //int i = 0;
            //foreach (Form frm in Application.OpenForms)
            //{
            ////    if (frm.GetType().Name == "saildueupdate")
            ////    {
            ////        i = 1;
            ////        return;
            ////    }
            ////}
            ////if (i == 0)
            ////{
            ////    sales_returns st = new sales_returns();
            ////    st.MdiParent = this;
            ////    st.Show();
            //}
        }

        private void SaleToolStripMenuItem_Click(object sender, EventArgs e)
        {

            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "Sale")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                Sale st = new Sale();
                st.MdiParent = this;
                st.Show();
            }
        }

        private void purchaseToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "purchases")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                purchases pr = new purchases();
                pr.MdiParent = this;
                pr.Show();
            }

        }

        private void salesReturnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "sales_return")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                sales_return st = new sales_return();
                st.MdiParent = this;
                st.Show();
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            statusBar1.Panels[0].Text = DateTime.Now.ToString("hh:mm tt:ddd ");
            statusBar1.Panels[1].Text = DateTime.Now.ToString("dd/MM/ yyyy ");
            
        }

        private void dateTimePicker1_ValueChanged_1(object sender, EventArgs e)
        {
          
        }

        private void purchaseReturnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            purchase_return pr = new purchase_return();
            pr.Show();

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        public static bool a = true;
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (a)
            
            label1.Location = new Point(label1.Location.X+5, label1.Location.Y);
            else
            label1.Location = new Point(label1.Location.X -650, label1.Location.Y);
            if (label1.Location.X + label1.Width >= this.Width+180)
             a = false;
            
             if(label1.Location.X <= 0)
                a= true;

            

        }

        private void statusBar1_PanelClick(object sender, StatusBarPanelClickEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

           
        }

        private void gOTOCAMERAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Form1 f1 = new Form1();
           // f1.Show();
            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "camera")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                camera ctg = new camera();
                ctg.MdiParent = this;
                ctg.Show();
            }
        }

        private void oLDMOBILESalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "Old_Mobile-Sales")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                Old_Mobile_Sales ctg = new Old_Mobile_Sales();
                ctg.MdiParent = this;
                ctg.Show();
            }
        }

        private void oLDRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void oLDStockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "Old_Stock")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                Old_Stock ctg = new Old_Stock();
                ctg.MdiParent = this;
                ctg.Show();
            }
        }

        private void oLDMOBILEPurchaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i = 0;
            foreach (Form frm in Application.OpenForms)
            {
                if (frm.GetType().Name == "Old_Mobile_Purchase")
                {
                    i = 1;
                    return;
                }
            }
            if (i == 0)
            {
                Old_Mobile_Purchase ctg = new Old_Mobile_Purchase();
                ctg.MdiParent = this;
                ctg.Show();
            }   
        }
        

        //after login processes.......

    }
}
