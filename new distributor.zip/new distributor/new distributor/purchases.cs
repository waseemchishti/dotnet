﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;
using System.Data.SqlClient;

namespace new_distributor
{
    public partial class purchases : Form
    {
        public purchases()
        {
            InitializeComponent();
        }

        double tbill;
        double bill;
        double ttbil;
        int quantity;
        int tquantity;
        int ttquantity;

        DataTable dt = new DataTable();
        DataRow dr;
        BAL bl = new BAL();

        SqlConnection con = new SqlConnection(@"Data Source=desktop-lc4ovj7\sqlexpress;Initial Catalog=awan_distributor;Integrated Security=True");
        private void purchases_Load(object sender, EventArgs e)
        {

            compny_name();
            get_p_name();
            dt.Columns.Add("Detail Id");
            dt.Columns.Add("INvoice#");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("UNit PRice");
            dt.Columns.Add("Product ID");
            dt.Columns.Add("Bill");
            dt.Columns.Add("Product Name");
        }

        private void get_p_name()
        {

            DataTable tb = new DataTable();

            tb = bl.p_search_name();
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    cbproname.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                }
            }

        }
        private void compny_name()
        {
            bl.compnyname();
            for(int i=0;i<bl.compnyname().Rows.Count;i++)
            {
                cbcompname.Items.Add(bl.compnyname().Rows[i].ItemArray[0].ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnsdadd_Click(object sender, EventArgs e)
        {
            bill = Convert.ToDouble(txtbill.Text);
            tbill = tbill + bill;
            txttbill.Text = tbill.ToString();


            quantity = Convert.ToInt32(txtquantity.Text);
            tquantity += quantity;
            txttquantity.Text = tquantity.ToString();


            dr = dt.NewRow();
            dr["Detail Id"] = txtsaleid.Text;
            dr["INvoice#"] = txtinvoiceno.Text;
            dr["Quantity"] = txtquantity.Text;
            dr["UNit PRice"] = txtuprice.Text;
            dr["Product ID"] = lbpid.Text;
            dr["Bill"] = txtbill.Text;
            dr["Product Name"] = cbproname.Text;
            dt.Rows.Add(dr);
            dataGridView1.DataSource = dt;
            lbrows.Text = dt.Rows.Count.ToString();

            txtsaleid.Text = "";
            // txtinvoiceno.Text = "";
            txtquantity.Text = "";
            txtuprice.Text = "";
            cbproname.Text = "";
            txtbill.Text = "";
        }

        private void txtuprice_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtdiscount_TextChanged(object sender, EventArgs e)
        {
            if (txtdiscount.Text == "")
            {

            }
            else
            {

                if (txtdiscount.Text == "")
                {
                    return;
                }
                double dis = Convert.ToDouble(txtdiscount.Text);
                double tbill = Convert.ToDouble(txttbill.Text);
                double res = (dis / 100) * tbill;
                txtnbill.Text = (tbill - res).ToString();
            }

        }

        private void txtcpaid_TextChanged(object sender, EventArgs e)
        {
            if (txtcpaid.Text == "")
            {

            }
            else
            {

                if (txtcpaid.Text == "")
                {
                    return;
                }

                double nbil = Convert.ToDouble(txtnbill.Text);
                double cashp = Convert.ToDouble(txtcpaid.Text);
                double res = (nbil - cashp);
                txtdamount.Text = res.ToString();

            }
        }

        private void txtinvoiceno_TextChanged(object sender, EventArgs e)
        {
            if (txtinvoiceno.Text == "")
            {

            }
            else
            {

                if (txtinvoiceno.Text == "")
                {
                    return;
                }

                txtinvoice.Text = txtinvoiceno.Text;
            }
        }

        private void cbproname_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id;

            id = bl.get_p_id(cbproname.Text).Rows[0].ItemArray[0].ToString();
            if (bl.get_p_id(cbproname.Text).Rows.Count > 0)
            {
                lbpid.Text = id;

            }
            if (bl.stokqpsearch(id).Rows.Count > 0)
            {

                string stkprice = bl.stokqpsearch(id).Rows[0].ItemArray[3].ToString();

                txtuprice.Text = stkprice;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlTransaction trans;

            con.Open();
            trans = con.BeginTransaction();
            try
            {

                if (dataGridView1.Rows.Count <= 0)
                {
                    MessageBox.Show("First Add product to cart");
                }


                SqlCommand cmd = new SqlCommand("pmain_insert", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@inv", txtinvoice.Text);
                cmd.Parameters.AddWithValue("@tquan", txttquantity.Text);
                cmd.Parameters.AddWithValue("@tbill", txttbill.Text);
                cmd.Parameters.AddWithValue("@dis", txtdiscount.Text);
                cmd.Parameters.AddWithValue("@nbill", txtnbill.Text);
                cmd.Parameters.AddWithValue("@cpaid", txtcpaid.Text);
                cmd.Parameters.AddWithValue("@due", txtdamount.Text);
                cmd.Parameters.AddWithValue("@datep", dateTimePicker1.Text);
                cmd.Parameters.AddWithValue("@cmname", cbcompname.Text);
                cmd.Transaction = trans;
                cmd.ExecuteNonQuery();
                //company update

                SqlCommand scmd = new SqlCommand("compnydueupdate", con);
                    scmd.CommandType = CommandType.StoredProcedure;
                    scmd.Parameters.AddWithValue("@cname",cbcompname.Text);
                    scmd.Parameters.AddWithValue("@due",txtdamount.Text);
                    scmd.Transaction = trans;
                    scmd.ExecuteNonQuery();


                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    //product detail insert

                    SqlCommand cmdd = new SqlCommand("pdetail_insert", con);
                    cmdd.CommandType = CommandType.StoredProcedure;
                    cmdd.Parameters.AddWithValue("@ppid", dataGridView1.Rows[i].Cells["Detail Id"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@inv", dataGridView1.Rows[i].Cells["INvoice#"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@pid", dataGridView1.Rows[i].Cells["Product ID"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@qua", dataGridView1.Rows[i].Cells["Quantity"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@uprice", dataGridView1.Rows[i].Cells["UNit PRice"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@bill", dataGridView1.Rows[i].Cells["Bill"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@pname", dataGridView1.Rows[i].Cells["Product Name"].Value.ToString());
                    cmdd.Transaction = trans;
                    cmdd.ExecuteNonQuery();      

                    // stock purchase quantity update

                    string quan = dataGridView1.Rows[i].Cells["Quantity"].Value.ToString();
                   // int rs = Convert.ToInt32(quan);
                    string pid = dataGridView1.Rows[i].Cells["Product ID"].Value.ToString();
                    string price = dataGridView1.Rows[i].Cells["UNit PRice"].Value.ToString();
                    //stock update
                    SqlCommand comand = new SqlCommand("stockpurchaseupdate", con);
                    comand.CommandType = CommandType.StoredProcedure;
                    comand.Parameters.AddWithValue("@quan", quan);
                    comand.Parameters.AddWithValue("@uprice",price);
                    comand.Parameters.AddWithValue("@pid", pid);
                    comand.Transaction = trans;
                    comand.ExecuteNonQuery();
                }
                trans.Commit();

                MessageBox.Show("data Saved to database");
                //..........................
                txtinvoice.Text = "";
                txttquantity.Text = "";
                txttbill.Text = "";
                txtdiscount.Text = "";
                txtnbill.Text = "";
                txtcpaid.Text = "";
                txtdamount.Text = "";
                txtsaleid.Text = "";
                lbrows.Text = "";
                dataGridView1.DataSource = null;
            }

            catch (Exception ex)
            {
                trans.Rollback();
                MessageBox.Show(ex.ToString());
                // throw ex;

            }

            con.Close();
        }

        private void txtquantity_TextChanged(object sender, EventArgs e)
        {
            if (txtquantity.Text == "")
            {

            }
            else
            {
                if (txtquantity.Text == "")
                {
                    return;
                }


                double q = Convert.ToDouble(txtquantity.Text);
                double p = Convert.ToDouble(txtuprice.Text);
                double res = q * p;
                txtbill.Text = res.ToString();
            }



        }

        private void cbcompname_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
