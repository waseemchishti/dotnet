﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;

namespace new_distributor
{
    public partial class purchase_return_detail_check : Form
    {
        BAL bl = new BAL();
        public purchase_return_detail_check()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = bl.pdetail_check(textBox1.Text);

        }
    }
}
