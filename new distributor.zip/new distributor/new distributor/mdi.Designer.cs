﻿namespace new_distributor
{
    partial class mdi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mdi));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catproToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cATEGORYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pRODUCTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.companyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesmanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseReturnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dueUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesReturnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stocktoolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gOTOCAMERAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.statusBar1 = new System.Windows.Forms.StatusBar();
            this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
            this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.oLDRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oLDMOBILESalesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oLDStockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oLDMOBILEPurchaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hhToolStripMenuItem,
            this.catproToolStripMenuItem,
            this.accountsToolStripMenuItem,
            this.purchaseToolStripMenuItem,
            this.saleToolStripMenuItem,
            this.stocktoolStripMenuItem1,
            this.gOTOCAMERAToolStripMenuItem,
            this.oLDRecordToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(939, 89);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // hhToolStripMenuItem
            // 
            this.hhToolStripMenuItem.AutoSize = false;
            this.hhToolStripMenuItem.BackColor = System.Drawing.Color.Gainsboro;
            this.hhToolStripMenuItem.BackgroundImage = global::new_distributor.Properties.Resources.logo;
            this.hhToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hhToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.hhToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.hhToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.hhToolStripMenuItem.Name = "hhToolStripMenuItem";
            this.hhToolStripMenuItem.Size = new System.Drawing.Size(120, 100);
            // 
            // catproToolStripMenuItem
            // 
            this.catproToolStripMenuItem.AutoSize = false;
            this.catproToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cATEGORYToolStripMenuItem,
            this.pRODUCTToolStripMenuItem,
            this.eXITToolStripMenuItem});
            this.catproToolStripMenuItem.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.catproToolStripMenuItem.ForeColor = System.Drawing.Color.Yellow;
            this.catproToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.White;
            this.catproToolStripMenuItem.Name = "catproToolStripMenuItem";
            this.catproToolStripMenuItem.Size = new System.Drawing.Size(94, 60);
            this.catproToolStripMenuItem.Text = "Select";
            this.catproToolStripMenuItem.Click += new System.EventHandler(this.catproToolStripMenuItem_Click);
            // 
            // cATEGORYToolStripMenuItem
            // 
            this.cATEGORYToolStripMenuItem.Name = "cATEGORYToolStripMenuItem";
            this.cATEGORYToolStripMenuItem.ShortcutKeyDisplayString = "";
            this.cATEGORYToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.cATEGORYToolStripMenuItem.Size = new System.Drawing.Size(296, 30);
            this.cATEGORYToolStripMenuItem.Text = "CATEGORY";
            this.cATEGORYToolStripMenuItem.Click += new System.EventHandler(this.cATEGORYToolStripMenuItem_Click);
            // 
            // pRODUCTToolStripMenuItem
            // 
            this.pRODUCTToolStripMenuItem.Name = "pRODUCTToolStripMenuItem";
            this.pRODUCTToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.pRODUCTToolStripMenuItem.Size = new System.Drawing.Size(296, 30);
            this.pRODUCTToolStripMenuItem.Text = "PRODUCT";
            this.pRODUCTToolStripMenuItem.Click += new System.EventHandler(this.pRODUCTToolStripMenuItem_Click);
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(296, 30);
            this.eXITToolStripMenuItem.Text = "EXIT";
            // 
            // accountsToolStripMenuItem
            // 
            this.accountsToolStripMenuItem.AutoSize = false;
            this.accountsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.companyToolStripMenuItem,
            this.salesmanToolStripMenuItem});
            this.accountsToolStripMenuItem.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accountsToolStripMenuItem.ForeColor = System.Drawing.Color.Yellow;
            this.accountsToolStripMenuItem.Name = "accountsToolStripMenuItem";
            this.accountsToolStripMenuItem.Size = new System.Drawing.Size(94, 70);
            this.accountsToolStripMenuItem.Text = "Accounts";
            // 
            // companyToolStripMenuItem
            // 
            this.companyToolStripMenuItem.Name = "companyToolStripMenuItem";
            this.companyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.C)));
            this.companyToolStripMenuItem.Size = new System.Drawing.Size(222, 30);
            this.companyToolStripMenuItem.Text = "Company";
            this.companyToolStripMenuItem.Click += new System.EventHandler(this.companyToolStripMenuItem_Click);
            // 
            // salesmanToolStripMenuItem
            // 
            this.salesmanToolStripMenuItem.Name = "salesmanToolStripMenuItem";
            this.salesmanToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.salesmanToolStripMenuItem.Size = new System.Drawing.Size(222, 30);
            this.salesmanToolStripMenuItem.Text = "Salesman";
            this.salesmanToolStripMenuItem.Click += new System.EventHandler(this.salesmanToolStripMenuItem_Click);
            // 
            // purchaseToolStripMenuItem
            // 
            this.purchaseToolStripMenuItem.AutoSize = false;
            this.purchaseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.purchaseToolStripMenuItem1,
            this.purchaseReturnToolStripMenuItem});
            this.purchaseToolStripMenuItem.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.purchaseToolStripMenuItem.ForeColor = System.Drawing.Color.Yellow;
            this.purchaseToolStripMenuItem.Name = "purchaseToolStripMenuItem";
            this.purchaseToolStripMenuItem.Size = new System.Drawing.Size(94, 60);
            this.purchaseToolStripMenuItem.Text = "Purchases";
            this.purchaseToolStripMenuItem.Click += new System.EventHandler(this.purchaseToolStripMenuItem_Click);
            // 
            // purchaseToolStripMenuItem1
            // 
            this.purchaseToolStripMenuItem1.Name = "purchaseToolStripMenuItem1";
            this.purchaseToolStripMenuItem1.Size = new System.Drawing.Size(226, 30);
            this.purchaseToolStripMenuItem1.Text = "Purchase";
            this.purchaseToolStripMenuItem1.Click += new System.EventHandler(this.purchaseToolStripMenuItem1_Click);
            // 
            // purchaseReturnToolStripMenuItem
            // 
            this.purchaseReturnToolStripMenuItem.Name = "purchaseReturnToolStripMenuItem";
            this.purchaseReturnToolStripMenuItem.Size = new System.Drawing.Size(226, 30);
            this.purchaseReturnToolStripMenuItem.Text = "Purchase Return";
            this.purchaseReturnToolStripMenuItem.Click += new System.EventHandler(this.purchaseReturnToolStripMenuItem_Click);
            // 
            // saleToolStripMenuItem
            // 
            this.saleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dueUpdateToolStripMenuItem,
            this.salesReturnToolStripMenuItem});
            this.saleToolStripMenuItem.Font = new System.Drawing.Font("Arial", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saleToolStripMenuItem.ForeColor = System.Drawing.Color.Yellow;
            this.saleToolStripMenuItem.Name = "saleToolStripMenuItem";
            this.saleToolStripMenuItem.Size = new System.Drawing.Size(77, 85);
            this.saleToolStripMenuItem.Text = "Sales";
            this.saleToolStripMenuItem.Click += new System.EventHandler(this.saleToolStripMenuItem_Click);
            // 
            // dueUpdateToolStripMenuItem
            // 
            this.dueUpdateToolStripMenuItem.Name = "dueUpdateToolStripMenuItem";
            this.dueUpdateToolStripMenuItem.Size = new System.Drawing.Size(215, 28);
            this.dueUpdateToolStripMenuItem.Text = "Sale";
            this.dueUpdateToolStripMenuItem.Click += new System.EventHandler(this.SaleToolStripMenuItem_Click);
            // 
            // salesReturnToolStripMenuItem
            // 
            this.salesReturnToolStripMenuItem.Name = "salesReturnToolStripMenuItem";
            this.salesReturnToolStripMenuItem.Size = new System.Drawing.Size(215, 28);
            this.salesReturnToolStripMenuItem.Text = "Sales_Return";
            this.salesReturnToolStripMenuItem.Click += new System.EventHandler(this.salesReturnToolStripMenuItem_Click);
            // 
            // stocktoolStripMenuItem1
            // 
            this.stocktoolStripMenuItem1.AutoSize = false;
            this.stocktoolStripMenuItem1.Font = new System.Drawing.Font("Arial Narrow", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stocktoolStripMenuItem1.ForeColor = System.Drawing.Color.Yellow;
            this.stocktoolStripMenuItem1.Name = "stocktoolStripMenuItem1";
            this.stocktoolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.stocktoolStripMenuItem1.Size = new System.Drawing.Size(94, 60);
            this.stocktoolStripMenuItem1.Text = "Stock";
            this.stocktoolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // gOTOCAMERAToolStripMenuItem
            // 
            this.gOTOCAMERAToolStripMenuItem.Font = new System.Drawing.Font("Arial Black", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gOTOCAMERAToolStripMenuItem.ForeColor = System.Drawing.Color.Yellow;
            this.gOTOCAMERAToolStripMenuItem.Name = "gOTOCAMERAToolStripMenuItem";
            this.gOTOCAMERAToolStripMenuItem.Size = new System.Drawing.Size(152, 85);
            this.gOTOCAMERAToolStripMenuItem.Text = "GOTO CAMERA";
            this.gOTOCAMERAToolStripMenuItem.Click += new System.EventHandler(this.gOTOCAMERAToolStripMenuItem_Click);
            // 
            // statusBar1
            // 
            this.statusBar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusBar1.Location = new System.Drawing.Point(0, 460);
            this.statusBar1.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
            this.statusBar1.Name = "statusBar1";
            this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.statusBarPanel1,
            this.statusBarPanel2});
            this.statusBar1.ShowPanels = true;
            this.statusBar1.Size = new System.Drawing.Size(939, 45);
            this.statusBar1.TabIndex = 4;
            this.statusBar1.PanelClick += new System.Windows.Forms.StatusBarPanelClickEventHandler(this.statusBar1_PanelClick);
            // 
            // statusBarPanel1
            // 
            this.statusBarPanel1.Name = "statusBarPanel1";
            this.statusBarPanel1.Text = "statusBarPanel1";
            // 
            // statusBarPanel2
            // 
            this.statusBarPanel2.Name = "statusBarPanel2";
            this.statusBarPanel2.Text = "statusBarPanel2";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(12, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(526, 34);
            this.label1.TabIndex = 6;
            this.label1.Text = "Your Favourite Place Where You Find Yourself Secure";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // oLDRecordToolStripMenuItem
            // 
            this.oLDRecordToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oLDMOBILESalesToolStripMenuItem,
            this.oLDStockToolStripMenuItem,
            this.oLDMOBILEPurchaseToolStripMenuItem});
            this.oLDRecordToolStripMenuItem.Font = new System.Drawing.Font("Andalus", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oLDRecordToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.oLDRecordToolStripMenuItem.Name = "oLDRecordToolStripMenuItem";
            this.oLDRecordToolStripMenuItem.Size = new System.Drawing.Size(140, 85);
            this.oLDRecordToolStripMenuItem.Text = "OLD Record";
            this.oLDRecordToolStripMenuItem.Click += new System.EventHandler(this.oLDRecordToolStripMenuItem_Click);
            // 
            // oLDMOBILESalesToolStripMenuItem
            // 
            this.oLDMOBILESalesToolStripMenuItem.Name = "oLDMOBILESalesToolStripMenuItem";
            this.oLDMOBILESalesToolStripMenuItem.Size = new System.Drawing.Size(308, 38);
            this.oLDMOBILESalesToolStripMenuItem.Text = "OLD MOBILE Sales";
            this.oLDMOBILESalesToolStripMenuItem.Click += new System.EventHandler(this.oLDMOBILESalesToolStripMenuItem_Click);
            // 
            // oLDStockToolStripMenuItem
            // 
            this.oLDStockToolStripMenuItem.Name = "oLDStockToolStripMenuItem";
            this.oLDStockToolStripMenuItem.Size = new System.Drawing.Size(308, 38);
            this.oLDStockToolStripMenuItem.Text = "OLD Stock";
            this.oLDStockToolStripMenuItem.Click += new System.EventHandler(this.oLDStockToolStripMenuItem_Click);
            // 
            // oLDMOBILEPurchaseToolStripMenuItem
            // 
            this.oLDMOBILEPurchaseToolStripMenuItem.Name = "oLDMOBILEPurchaseToolStripMenuItem";
            this.oLDMOBILEPurchaseToolStripMenuItem.Size = new System.Drawing.Size(308, 38);
            this.oLDMOBILEPurchaseToolStripMenuItem.Text = "OLD MOBILE Purchase";
            this.oLDMOBILEPurchaseToolStripMenuItem.Click += new System.EventHandler(this.oLDMOBILEPurchaseToolStripMenuItem_Click);
            // 
            // mdi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(939, 505);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.statusBar1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.Color.Green;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "mdi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.mdi_FormClosing);
            this.Load += new System.EventHandler(this.mdi_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem catproToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cATEGORYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.Windows.Forms.ToolStripMenuItem accountsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem companyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesmanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stocktoolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dueUpdateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchaseToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem purchaseReturnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesReturnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hhToolStripMenuItem;
        private System.Windows.Forms.StatusBar statusBar1;
        private System.Windows.Forms.StatusBarPanel statusBarPanel1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.StatusBarPanel statusBarPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ToolStripMenuItem gOTOCAMERAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oLDRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oLDMOBILESalesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oLDStockToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oLDMOBILEPurchaseToolStripMenuItem;
    }
}