﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;
using System.Data.SqlClient;

namespace new_distributor
{
    public partial class Old_Mobile_Purchase : Form
    {
        public Old_Mobile_Purchase()
        {
            InitializeComponent();
        }
        BAL bl = new BAL();
        string pic = null;
        //string pic = null;
        string img;
        DataRow dr;
        DataTable dt = new DataTable();
        private void Old_Stock_Load(object sender, EventArgs e)
        {
            DataTable tb = new DataTable();
            tb = bl.c_search_name();
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    comboBox2.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                }
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnpic_Click(object sender, EventArgs e)
        {
            var imgfilter = openFileDialog1;
            imgfilter.Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif; *.ico");
            imgfilter.FilterIndex = 4;
            DialogResult dresult;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pic = openFileDialog1.FileName;
                pictureBox1.Load(pic);

            }
            else
            {

                dresult = MessageBox.Show("picture not uploaded", "Upload Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
            doo:
                if (dresult == DialogResult.Retry)
                {

                    if (openFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        pic = openFileDialog1.FileName;
                        pictureBox1.Load(pic);

                    }
                    else
                    {
                        dresult = MessageBox.Show("picture not uploaded", "Upload Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);

                    }
                    goto doo;
                }


                pictureBox1.Image = null;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var imgfilter = openFileDialog2;
            imgfilter.Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif; *.ico");
            imgfilter.FilterIndex = 4;
            DialogResult dresult;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
              //  pic2 = openFileDialog2.FileName;
                //pictureBox2.Load(pic2);

            }
            else
            {

                dresult = MessageBox.Show("picture not uploaded", "Upload Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
            doo:
                if (dresult == DialogResult.Retry)
                {

                    if (openFileDialog2.ShowDialog() == DialogResult.OK)
                    {
                       // pic2 = openFileDialog2.FileName;
                        //pictureBox2.Load(pic2);

                    }
                    else
                    {
                        dresult = MessageBox.Show("picture not uploaded", "Upload Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);

                    }
                    goto doo;
                }


                pictureBox2.Image = null;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void insert_Click(object sender, EventArgs e)
        {

             bl.old_purchase_insert(txtimei.Text, txtpname.Text, comboBox1.Text,txtxpmob.Text,txtpcity.Text, dateTimePicker1.Text,comboBox2.Text,comboBox3.Text,txtmodel.Text,txtpprice.Text,,pictureBox1.Image,pictureBox2,txtpcity.Text,
            //txtsmail.Text, cbscity.Text, rtxtaddress.Text,txtssalary.Text,pic,dateTimePicker1.Text);
            // saleaman_id();
           // dr = dt.NewRow();
            //dr["Detail Id"] = txtimei.Text;
            //dr["INvoice#"] = txtpname.Text;
            //dr["Quantity"] = pictureBox1.Image;
            //dt.Rows.Add(dr);
            //dataGridView1.DataSource = dt;
            //dr["UNit PRice"] = txtuprice.Text;
            //dr["Product ID"] = lbpid.Text;
            //dr["Bill"] = txtbill.Text;


           // SqlCommand cmd = new SqlCommand(@"insert into newsalesman(id,name,image)values('" + txtimei.Text + "','" + txtpname.Text + "','" + pictureBox1.Image + "')", con);
            //con.Open();
            //cmd.ExecuteNonQuery();
            //con.Close();
            /*
            txtimei.Text = "";
            txtpname.Text = "";
            comboBox1.Text = "";
            txtxpmob.Text = "";
            txtsmail.Text = "";
            txtpcity.Text = "";
            rtxtaddress.Text = "";
            txtpprice.Text = "";
            pictureBox1.Image = null;

            
            //dateTimePicker1.Text = "";
        */
            }
    }
}