﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;
using System.Data.SqlClient;

namespace new_distributor
{
    public partial class Old_Mobile_Sales : Form
    {
        public Old_Mobile_Sales()
        {
            InitializeComponent();
        }
        double tbill;
        double bill;
        double ttbil;
        int quantity;
        int tquantity;
        int ttquantity;

        DataTable dt = new DataTable();
        DataRow dr;
        BAL bl = new BAL();
        SqlConnection con = new SqlConnection(@"Data Source=desktop-lc4ovj7\sqlexpress;Initial Catalog=awan_distributor;Integrated Security=True");
      

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //tabPage3.Show();
            purchase_return_detail_check pr = new purchase_return_detail_check();
            pr.Show();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void insert_Click(object sender, EventArgs e)
        {

        }
    }
}
