﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;
using System.Data.SqlClient;

namespace new_distributor
{
    public partial class company : Form
    {
        public company()
        {
            InitializeComponent();
        }
        BAL bl = new BAL();


        //insert.........
        private void cominsert_Click(object sender, EventArgs e)
        {
           
                if (bl.com_name(company_name.Text).Rows.Count > 0)
                {

                    MessageBox.Show("This Company already exist,Please Add New Company", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    company_name.Text = "";
                    company_name.Focus();
                }
            else
                {
                    bl.com_insert(company_id.Text,company_name.Text, company_phone.Text, com_mobile.Text, companyEmail.Text, company_address.Text, com_city.Text, comp_due.Text);
                    comboBox1.Items.Clear();
                    get_com_name();

                    MessageBox.Show("Data inserted successfully");

                    company_id.Text = "";
                    company_name.Text = "";
                    company_phone.Text = "";
                    com_mobile.Text = "";
                    companyEmail.Text = "";
                    company_address.Text="";
                    com_city.Text="";
                    comp_due.Text = "";


                }
        }
        
        // delete............


        private void comdelete_Click(object sender, EventArgs e)
        {
            bl.com_delete (company_id.Text);
            comboBox1.Items.Clear();
            get_com_name();
            MessageBox.Show("Data Deleted successfully");
            company_id.Text = "";
            company_name.Text = "";
            company_phone.Text = "";
            com_mobile.Text = "";
            companyEmail.Text = "";
            company_address.Text = "";
            com_city.Text = "";
            comp_due.Text = "";
            dataGridView1.DataSource = null;
           
        }


        //update..........



        private void comupdate_Click(object sender, EventArgs e)
        {
            bl.com_update(company_id.Text, company_name.Text, company_phone.Text, com_mobile.Text, companyEmail.Text, company_address.Text, com_city.Text, comp_due.Text);

            comboBox1.Items.Clear();
            get_com_name();
            MessageBox.Show("Data updated successfully");
            company_id.Text = "";
            company_name.Text = "";
            company_phone.Text = "";
            com_mobile.Text = "";
            companyEmail.Text = "";
            company_address.Text = "";
            com_city.Text = "";
            comp_due.Text = "";
            dataGridView1.DataSource = null;
        }


        //search............



        private void comsearch_Click(object sender, EventArgs e)
        {
            
            dataGridView1.DataSource = bl.com_search(company_id.Text);

        
        }


        //get or loading name.............in combobox.......


       
        private void get_com_name()
        {
            DataTable tb = new DataTable();
            tb = bl.com_loading_name();
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    comboBox1.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                }
            }

        }


        //loading name in form.........
        private void company_Load(object sender, EventArgs e)
        {
            get_com_name();
        }


        // get id using name in combobox................


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id;
            id = bl.get_com_id(comboBox1.Text).Rows[0].ItemArray[0].ToString();
            company_id.Text = id;
        }


        // searching company by name...................




        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = bl.com_byname(comboBox1.Text);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            company_id.Text=dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            company_name.Text=dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            company_phone.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            com_mobile.Text= dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            companyEmail.Text= dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            company_address.Text= dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            com_city.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            comp_due.Text= dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
  
        }

        private void company_name_TextChanged(object sender, EventArgs e)
        {
            
        }
        

        
    }
}
