﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;
using System.Data.SqlClient;

namespace new_distributor
{
    public partial class salesman : Form
    {
        public salesman()
        {
            InitializeComponent();
        }

        BAL bl = new BAL();
        string pic = null;
        string img;
        DataRow dr;
        DataTable dt = new DataTable();
        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-LC4OVJ7\SQLEXPRESS;Initial Catalog=awan_distributor;Integrated Security=True");
        private void insert_Click(object sender, EventArgs e)
        {
        
           // bl.salesman_insert(txtsid.Text, txtsname.Text, comboBox1.Text,txtxsmobile.Text,
           //txtsmail.Text, cbscity.Text, rtxtaddress.Text,txtssalary.Text,pic,dateTimePicker1.Text);
           // saleaman_id();
            dr = dt.NewRow();
            dr["Detail Id"] = txtsid.Text;
            dr["INvoice#"] = txtsname.Text;
            dr["Quantity"] = pictureBox1.Image;
            dt.Rows.Add(dr);
            dataGridView1.DataSource = dt;
            //dr["UNit PRice"] = txtuprice.Text;
            //dr["Product ID"] = lbpid.Text;
            //dr["Bill"] = txtbill.Text;
            
            
            SqlCommand cmd = new SqlCommand(@"insert into newsalesman(id,name,image)values('" +txtsid.Text + "','" + txtsname.Text + "','" + pictureBox1.Image+ "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            txtsid.Text = "";
            txtsname.Text = "";
            comboBox1.Text = "";
            txtxsmobile.Text = "";
            txtsmail.Text = "";
            cbscity.Text = "";
            rtxtaddress.Text = "";
            txtssalary.Text = "";
            pictureBox1.Image = null;
           
            
           //dateTimePicker1.Text = "";
        }

        private void delete_Click(object sender, EventArgs e)
        {
            bl.salesman_delete(txtsid.Text);

            txtsid.Text = "";
            txtsname.Text = "";
            comboBox1.Text = "";
            txtxsmobile.Text = "";
            txtsmail.Text = "";
            cbscity.Text = "";
            rtxtaddress.Text = "";
            txtssalary.Text = "";
            pictureBox1.Image = null;
            dateTimePicker1.Text = "";
        }

        private void update_Click(object sender, EventArgs e)
        {
            bl.smupdate(txtsid.Text, txtsname.Text, comboBox1.Text, txtxsmobile.Text, txtsmail.Text, cbscity.Text, rtxtaddress.Text, txtssalary.Text,pic, dateTimePicker1.Text, "0");
           // bl.salesmanupdate(SalesMan_ID.Text, SalesMan_Name.Text, comboBox1.Text, salesman_mobile.Text,
           //salesmanemail.Text, SalesMan_City.Text, richTextBox1.Text, salesman_salary.Text, pic, dateTimePicker1.Text,"0");
           MessageBox.Show("data updated");

            txtsid.Text = "";
            txtsname.Text = "";
            comboBox1.Text = "";
            txtxsmobile.Text = "";
            txtsmail.Text = "";
            cbscity.Text = "";
            rtxtaddress.Text = "";
            txtssalary.Text = "";
            pictureBox1.Image = null;
            //dateTimePicker1.Text = "";
        }
        int ro = 0;
        private void search_Click(object sender, EventArgs e)
        {
            dataGridView1 = null;
            SqlCommand cmd = new SqlCommand("select * from newsalesman where id='"+txtsid.Text+"'" , con);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            if (dt.Rows.Count > 0) {

                dataGridView1.DataSource = dt;
                //txtsid.Text = dt.Rows[0]["id"].ToString();

                //txtsname.Text = dt.Rows[0]["name"].ToString();

                //pictureBox1.Image = dt.Rows[0]["image"].ToString();


            }






           // DataTable dt = new DataTable();
            dt = bl.salesman_search(txtsid.Text);
            if (dt.Rows.Count > 0)
            {
                //dataGridView1.DataSource = null;
                Bitmap b = new Bitmap(dt.Rows[0].ItemArray[8].ToString());
                ((DataGridViewImageColumn)dataGridView1.Columns[0]).ImageLayout = DataGridViewImageCellLayout.Stretch;
                if (ro == 0)
                {
                    dataGridView1.RowTemplate.Height = 420;
                    dataGridView1.Rows.Add();
                    ro = 1;
                }

                dataGridView1.Rows[0].Cells[0].Value = dt.Rows[0].ItemArray[8].ToString();
                //dataGridView1.Rows[0].Cells[0].Value = b;

                dataGridView1.Rows[0].Cells[1].Value = dt.Rows[0].ItemArray[0].ToString();
                dataGridView1.Rows[0].Cells[2].Value = dt.Rows[0].ItemArray[1].ToString();
                dataGridView1.Rows[0].Cells[3].Value = dt.Rows[0].ItemArray[2].ToString();
                dataGridView1.Rows[0].Cells[4].Value = dt.Rows[0].ItemArray[3].ToString();
                dataGridView1.Rows[0].Cells[5].Value = dt.Rows[0].ItemArray[4].ToString();
                dataGridView1.Rows[0].Cells[6].Value = dt.Rows[0].ItemArray[5].ToString();
                dataGridView1.Rows[0].Cells[7].Value = dt.Rows[0].ItemArray[6].ToString();
                dataGridView1.Rows[0].Cells[8].Value = dt.Rows[0].ItemArray[7].ToString();
                dataGridView1.Rows[0].Cells[9].Value = dt.Rows[0].ItemArray[9].ToString();



            }
         // dataGridView1.DataSource = dt;
            else
            {

                MessageBox.Show("Data not found");
              //  dataGridView1.DataSource = null;
            }

        
            

        }
        
        private void btnpic_Click(object sender, EventArgs e)
        {
            var imgfilter = openFileDialog1;
            imgfilter.Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif; *.ico");
            imgfilter.FilterIndex = 4;
            DialogResult dresult;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pic = openFileDialog1.FileName;
                pictureBox1.Load(pic);

            }
            else
            {

                dresult = MessageBox.Show("picture not uploaded", "Upload Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
            doo:
                if(dresult == DialogResult.Retry)
                {
                     
                    if (openFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                       pic = openFileDialog1.FileName;
                        pictureBox1.Load(pic);

                    }
                    else
                    {
                        dresult = MessageBox.Show("picture not uploaded", "Upload Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
               
                    }
                    goto doo;
                }
                    
               
                pictureBox1.Image = null;


            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {

            if (dataGridView1.Rows.Count >= 0)
            {


                txtsid.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                txtsname.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                comboBox1.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                txtxsmobile.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                txtsmail.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                cbscity.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                rtxtaddress.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
                txtssalary.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
               //img= dataGridView1.SelectedRows[0].Cells["imag"].Value.ToString();
               // if(img=="")
               // {
               //    // pictureBox1.Image = null;
               //    // pictureBox1.Load(img);
               //     MessageBox.Show("img not found");
               //     pictureBox1.Image = null;
               // }
               // else
               // {
               //    // MessageBox.Show("img not found");
               //     //pictureBox1.Image = null;
               //     pictureBox1.Load(img); 
               // }
               
                //dateTimePicker1.Text = "";

               
               
            }
        }

        private void SalesMan_ID_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pic = openFileDialog1.FileName;
            pictureBox1.Load(pic);
        }

        private void salesman_Load(object sender, EventArgs e)
        {
     
            dt.Columns.Add("Detail Id");
            dt.Columns.Add("INvoice#");
            dt.Columns.Add("Quantity",typeof (Image));
            saleaman_id();
        
        }
        private void saleaman_id()
        {
            if (bl.salesmanID().Rows.Count > 0)
            {

                for (int i = 0; i < bl.salesmanID().Rows.Count; i++)
                {
                    combo_id.Items.Add(bl.salesmanID().Rows[i].ItemArray[0].ToString());
                }
            }

        }
        private void combo_id_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
