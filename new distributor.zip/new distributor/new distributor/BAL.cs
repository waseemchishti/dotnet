﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using new_distributor.data_access;
using System.Data;

namespace new_distributor.b_l
{
    class BAL
    {
        DAL da = new DAL();

        #region category.....

        //insert method..........
        public DataTable c_insert(string name, string des)
        {

            return da.c_insert(name, des);


        }
        //delete method...
        public void c_delete(string id)
        {

            da.c_delete(id);

        }
        //update method.............
        public void c_update(string id, string name, string des)
        {
            da.c_update(id, name, des);


        }
        //search method......
        public DataTable c_search(string id)
        {

            return da.c_search(id);
        }
        //loading category id.............
        public DataTable category_id()
        {
            return da.category_id();

        }
        //cat id check....
        public DataTable category_id_check(string id)
        {


            return da.category_id_check(id);

        }
        //search distinct cat name combobox....list items.......
        public DataTable c_search_name()
        {
            return da.c_search_name();

        }
        //searching category byname in comboBox..........
        public DataTable c_byname(string name)
        {

            return da.c_byname(name);



        }
        //loading product id..........
        public DataTable product_id()
        {
            return da.product_id();
        }
        // loading category name by id type................
        public DataTable c_search_name_type(string id)
        {
            return da.c_search_name_type(id);

        }
        //getting id by giving name in combobox.........
        public DataTable get_id(string name)
        {
            return da.get_id(name);

        }
        #endregion


        //product.....................................................................

        #region product
        public void p_insert(string id, string name, string type, string c_id, string up)
        {

            da.p_insert(id, name, type, c_id, up);


        }
        //delete method...
        public void p_delete(string id)
        {

            da.p_delete(id);

        }
        //update method.............
        public void p_update(string id, string name, string type, string c_id, string up)
        {
            da.p_update(id, name, type, c_id, up);


        }
        //search method......
        public DataTable p_search(string id)
        {

            return da.p_search(id);
        }
        //search distinct cat name combobox....list items.......
        public DataTable p_search_name()
        {
            return da.p_search_name();

        }
        //searching category byname in comboBox..........
        public DataTable p_byname(string name)
        {

            return da.p_byname(name);



        }
        //getting id by giving name in combobox.........
        public DataTable get_p_id(string name)
        {
            return da.get_p_id(name);

        }

        // loading products type in combo box in product page...............

        public DataTable get_type()
        {

            return da.get_type();

        }
        public DataTable get_cat_id_from_type(string type)
        {
           return da.get_cat_id_from_type(type);
        }
        #endregion
        // product type.................

        #region prudyct type
        //insert type,...........
        public DataTable p_t_insert(string type, string c_id)
        {
            return da.p_t_insert(type, c_id);
        }
        //delete type........

        public void type_delete(string name)
        {

            da.type_delete(name);

        }
        //update type..........................
        //...........................................
        public void type_update(string type, string c_id)
        {
            da.type_update(type, c_id);


        }
        // search type..........

        public DataTable type_search(string name)
        {
            return da.type_search(name);


        }

        #endregion


        //...............................................................company.....................................

        #region company..

        public DataTable com_insert(string id, string name, string ph, string mob, string email, string add, string city, string due)
        {
            return da.com_insert(id, name, ph, mob, email, add, city, due);
        }
        //delete company........

        public void com_delete(string id)
        {
            da.com_delete(id);

        }
        //update company..........................
        //...........................................
        public DataTable com_update(string id, string name, string ph, string mob, string email, string add, string city, string due)
        {
            return da.com_update(id, name, ph, mob, email, add, city, due);
        }
        // search company.......

        public DataTable com_search(string id)
        {
            return da.com_search(id);
        }
        // loading company by name.................
        public DataTable com_loading_name()
        {
            return da.com_loading_name();
        }
        //searching company byname in comboBox..........
        public DataTable com_byname(string name)
        {
            return da.com_byname(name);
        }
        //get company_id By name...............................
        public DataTable get_com_id(string name)
        {
            return da.get_com_id(name);
        }
        public DataTable com_name(string name)
        {
            return da.com_name(name);
        }

        public DataTable compnyname()
        {
            return da.compnyname();
        }
        #endregion


        #region saleman
        
        //insert salesman.............

        public void salesman_insert(string id, string name, string gender, string mob, string email, string city, string add, string salary, string pic, string date)
        {
            da.salesman_insert(id, name, gender, mob, email, city, add, salary, pic, date);
        }
        //delete salesman........

        public void salesman_delete(string id)
        {
            da.salesman_delete(id);

        }
        //update salesman..........................
        //...........................................
        public void smupdate(string sid, string name, string gender, string mob, string email, string city, string add, string salary, string img, string dat, string due)
        {

            da.smupdate(sid, name, gender, mob, email, city, add, salary, img, dat, due);

        }
        // search salesman.......

        public DataTable salesman_search(string id)
        {
            return da.salesman_search(id);
        }
        public DataTable salesmanname()
        {
            return da.salesmanname();
        }

        // loading salesman id..........
        public DataTable salesmanID()
        {
          return  da.salesmanID();

        }
        #endregion
        //...............................................stock ......................

        #region stock....
        public DataTable stock_insert(string id, string pid, string quantity, string unitp)
        {
            return da.stock_insert(id, pid, quantity, unitp);
        }
        //delete stock........

        public void stock_delete(string id)
        {
            da.stock_delete(id);
        }


        //stock search............................................

        public DataTable stock_search(string id)
        {
            return da.stock_search(id);
        }

        //update stock..........................
        //...........................................
        public DataTable stock_update(string id, string pid, string quantity, string unit_p)
        {

            return da.stock_update(id, pid, quantity, unit_p);

        }
        //stock quqntity view
        public DataTable stokqpsearch(string id)
        {
            return da.stokqpsearch(id);

        }
        public DataTable stock_id_search()
        {
            return da.stock_id_search();


        }

        #endregion

        #region sail product
        public void smain_delete(string invoice)
        {
            da.smain_delete(invoice);
        }
        public DataTable smain_search(string invoic)
        {
            return da.smain_search(invoic);
        }

        public DataTable smain_datesearch(string date)
        {
            return da.smain_datesearch(date);
        }

        public void smain_dueupdate(string invoice, string cashp, string due)
        {
            da.smain_dueupdate(invoice, cashp, due);
        }

        #endregion

        //............................................salereturn........................
        //public DataTable salesman_name()
        //{

        //    return da.salesman_name();

        //}
        //getting salesman_name..............
        public DataTable salesman_name(string id)
        {


            return da.salesman_name(id);

        }
        public DataTable salesman_id(string name)
        {

            return da.salesman_id(name);

        }
        // getting unit_price and quantity....................
        public DataTable sales_return_quantity_price(string invoice, string id)
        {

            return da.sales_return_quantity_price(invoice, id);

        }



        //getting discount from sales main into sales return...............
        public DataTable discount(string invoice)
        {

            return da.discount(invoice);
        }
        public void Login_insert(string name, string password, string acl, string at)
        {

            da.login_insert(name, password, acl);
        }
        // sales return detail search............
        public DataTable sales_return_detail_search(string id)
        {
            return da.sales_return_detail_search(id);


        }
        // sales_return_ main _ search ...............
        public DataTable sales_return_main_saerch(string id)
        {
            return da.sales_return_main_search(id);

        }

        ///....................old_purchse....................
        ///


        public void old_purchase_insert(int imei, string pname, string pgender, string pmob, string pcity,string pdate, string pcat, string pbrand, string pmodel, string pprice, string pimage, string mimage)
        {
            da.old_purchse_insert(imei,pname, pgender, pmob, pcity, pdate, pcat, pbrand, pmodel, pprice,pimage,mimage);
        }


        //.........................LOGIN..........................

        //Login Status................
        public DataTable login_status(string name, string pass, string access)
        {
            DataTable dt = new DataTable();

            return da.login_status(name, pass, access);

        }
        //  login_status_dupication.................
        public DataTable login_status_check(string name)
        {
            return da.login_status_check(name);

        }
        public DataTable login_acces_get(string name)
        {
            return da.login_acces_get(name);

        }
        //.................................purchase return.......................................
        public DataTable purchase_quantity_price(string id)
        {
            return da.purchase_quantity_price(id);



        }

        public DataTable purchase_return_did(string invoice, string id)
        {
            return da.purchase_return_did(invoice, id);



        }

        //.....purchase detail check.....New Form...........
        //..
        ///....
        ///....
        public DataTable pdetail_check(string invoice)
        {
            return da.pdetail_check(invoice);


        }

        public DataTable check_discount(string invoice)
        {

            return da.check_discount(invoice);


        }
        public DataTable pdetail_search(string id)
        {

            return da.pdetail_search(id);


        }




        //internal void salesman_insert(string p1, string p2, string p3, string p4, string p5, string p6, string p7, string p8, System.Windows.Forms.PictureBox picture, string p9)
        //{
        //    throw new NotImplementedException();
        //}
    }

       




    }


