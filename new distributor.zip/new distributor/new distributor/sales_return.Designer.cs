﻿namespace new_distributor
{
    partial class sales_return
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.detail_check_discount = new System.Windows.Forms.TextBox();
            this.check_quantity = new System.Windows.Forms.Label();
            this.detail_discount = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.salesman_detail_name = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.detail_quantity = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.invoice_detail = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.return_detail_id = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.product_id = new System.Windows.Forms.Label();
            this.detail_unit_price = new System.Windows.Forms.TextBox();
            this.detail_bill = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.main_quantity = new System.Windows.Forms.TextBox();
            this.invoice_no = new System.Windows.Forms.TextBox();
            this.main_return_id = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.main_total_bill = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.salesman_id = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.main_cash = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.main_due = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.saved = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.sales_return_discount = new System.Windows.Forms.TextBox();
            this.main_bill = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Location = new System.Drawing.Point(32, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1020, 390);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.BackgroundImage = global::new_distributor.Properties.Resources._1456931289_Cancel_Icon;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(945, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(69, 37);
            this.button3.TabIndex = 29;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(17, 45);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1014, 345);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.main_quantity);
            this.tabPage1.Controls.Add(this.invoice_no);
            this.tabPage1.Controls.Add(this.main_return_id);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1006, 319);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sales_Return";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(25, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 20);
            this.label17.TabIndex = 33;
            this.label17.Text = "Main";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(567, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 20);
            this.label16.TabIndex = 33;
            this.label16.Text = "Detail";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.detail_check_discount);
            this.groupBox2.Controls.Add(this.check_quantity);
            this.groupBox2.Controls.Add(this.detail_discount);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.salesman_detail_name);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.detail_quantity);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.invoice_detail);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.return_detail_id);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.product_id);
            this.groupBox2.Controls.Add(this.detail_unit_price);
            this.groupBox2.Controls.Add(this.detail_bill);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(571, 21);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(439, 295);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(299, 186);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 15);
            this.label21.TabIndex = 42;
            this.label21.Text = "Check_Discount";
            this.label21.Visible = false;
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // detail_check_discount
            // 
            this.detail_check_discount.Location = new System.Drawing.Point(297, 157);
            this.detail_check_discount.Multiline = true;
            this.detail_check_discount.Name = "detail_check_discount";
            this.detail_check_discount.Size = new System.Drawing.Size(100, 28);
            this.detail_check_discount.TabIndex = 36;
            this.detail_check_discount.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            this.detail_check_discount.MouseHover += new System.EventHandler(this.textBox1_MouseHover);
            // 
            // check_quantity
            // 
            this.check_quantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.check_quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check_quantity.Location = new System.Drawing.Point(269, 113);
            this.check_quantity.Name = "check_quantity";
            this.check_quantity.Size = new System.Drawing.Size(29, 25);
            this.check_quantity.TabIndex = 41;
            this.check_quantity.Click += new System.EventHandler(this.check_quantity_Click);
            // 
            // detail_discount
            // 
            this.detail_discount.AutoSize = true;
            this.detail_discount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detail_discount.Location = new System.Drawing.Point(301, 253);
            this.detail_discount.Name = "detail_discount";
            this.detail_discount.Size = new System.Drawing.Size(115, 15);
            this.detail_discount.TabIndex = 40;
            this.detail_discount.Text = "Discounted_Person";
            this.detail_discount.Visible = false;
            this.detail_discount.Click += new System.EventHandler(this.detail_discount_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(321, 58);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(79, 28);
            this.textBox2.TabIndex = 38;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(300, 89);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 15);
            this.label10.TabIndex = 37;
            this.label10.Text = "Item_Return_Id search";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // salesman_detail_name
            // 
            this.salesman_detail_name.Location = new System.Drawing.Point(295, 11);
            this.salesman_detail_name.Multiline = true;
            this.salesman_detail_name.Name = "salesman_detail_name";
            this.salesman_detail_name.Size = new System.Drawing.Size(121, 28);
            this.salesman_detail_name.TabIndex = 36;
            this.salesman_detail_name.TextChanged += new System.EventHandler(this.salesman_detail_name_TextChanged_1);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(305, 39);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(104, 15);
            this.label19.TabIndex = 34;
            this.label19.Text = "Salesman_Name";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(19, 118);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 20);
            this.label14.TabIndex = 32;
            this.label14.Text = "Quantity";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // detail_quantity
            // 
            this.detail_quantity.Location = new System.Drawing.Point(163, 113);
            this.detail_quantity.Multiline = true;
            this.detail_quantity.Name = "detail_quantity";
            this.detail_quantity.Size = new System.Drawing.Size(100, 28);
            this.detail_quantity.TabIndex = 31;
            this.detail_quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detail_quantity.TextChanged += new System.EventHandler(this.detail_quantity_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(19, 15);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 20);
            this.label13.TabIndex = 30;
            this.label13.Text = "Invoice_No";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // invoice_detail
            // 
            this.invoice_detail.Location = new System.Drawing.Point(163, 11);
            this.invoice_detail.Multiline = true;
            this.invoice_detail.Name = "invoice_detail";
            this.invoice_detail.Size = new System.Drawing.Size(100, 28);
            this.invoice_detail.TabIndex = 30;
            this.invoice_detail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.invoice_detail.TextChanged += new System.EventHandler(this.invoice_detail_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 20);
            this.label3.TabIndex = 29;
            this.label3.Text = "Return_Id";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // return_detail_id
            // 
            this.return_detail_id.Location = new System.Drawing.Point(163, 45);
            this.return_detail_id.Multiline = true;
            this.return_detail_id.Name = "return_detail_id";
            this.return_detail_id.Size = new System.Drawing.Size(100, 28);
            this.return_detail_id.TabIndex = 28;
            this.return_detail_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.return_detail_id.TextChanged += new System.EventHandler(this.return_detail_id_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(72, 239);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 37);
            this.button1.TabIndex = 0;
            this.button1.Text = "Add To Cart";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(163, 83);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 21);
            this.comboBox1.TabIndex = 11;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            this.comboBox1.MouseHover += new System.EventHandler(this.comboBox1_MouseHover);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Product_Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // product_id
            // 
            this.product_id.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.product_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.product_id.Location = new System.Drawing.Point(269, 80);
            this.product_id.Name = "product_id";
            this.product_id.Size = new System.Drawing.Size(29, 25);
            this.product_id.TabIndex = 3;
            this.product_id.Click += new System.EventHandler(this.product_id_Click);
            // 
            // detail_unit_price
            // 
            this.detail_unit_price.Location = new System.Drawing.Point(163, 147);
            this.detail_unit_price.Multiline = true;
            this.detail_unit_price.Name = "detail_unit_price";
            this.detail_unit_price.Size = new System.Drawing.Size(100, 28);
            this.detail_unit_price.TabIndex = 13;
            this.detail_unit_price.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detail_unit_price.TextChanged += new System.EventHandler(this.detail_unit_price_TextChanged);
            // 
            // detail_bill
            // 
            this.detail_bill.Location = new System.Drawing.Point(163, 181);
            this.detail_bill.Multiline = true;
            this.detail_bill.Name = "detail_bill";
            this.detail_bill.Size = new System.Drawing.Size(100, 28);
            this.detail_bill.TabIndex = 14;
            this.detail_bill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detail_bill.TextChanged += new System.EventHandler(this.detail_bill_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(19, 155);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 20);
            this.label8.TabIndex = 8;
            this.label8.Text = "Unit_Price";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(19, 186);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 20);
            this.label7.TabIndex = 7;
            this.label7.Text = "Bill";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Return_Id";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // main_quantity
            // 
            this.main_quantity.Location = new System.Drawing.Point(178, 97);
            this.main_quantity.Multiline = true;
            this.main_quantity.Name = "main_quantity";
            this.main_quantity.Size = new System.Drawing.Size(100, 28);
            this.main_quantity.TabIndex = 12;
            this.main_quantity.TextChanged += new System.EventHandler(this.main_quantity_TextChanged);
            // 
            // invoice_no
            // 
            this.invoice_no.Location = new System.Drawing.Point(178, 63);
            this.invoice_no.Multiline = true;
            this.invoice_no.Name = "invoice_no";
            this.invoice_no.Size = new System.Drawing.Size(100, 28);
            this.invoice_no.TabIndex = 10;
            this.invoice_no.TextChanged += new System.EventHandler(this.invoice_no_TextChanged);
            // 
            // main_return_id
            // 
            this.main_return_id.Location = new System.Drawing.Point(178, 32);
            this.main_return_id.Multiline = true;
            this.main_return_id.Name = "main_return_id";
            this.main_return_id.Size = new System.Drawing.Size(100, 28);
            this.main_return_id.TabIndex = 9;
            this.main_return_id.TextChanged += new System.EventHandler(this.main_return_id_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(52, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Invoice_No";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.main_total_bill);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.salesman_id);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.main_cash);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.dateTimePicker1);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.main_due);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.sales_return_discount);
            this.groupBox3.Controls.Add(this.main_bill);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(29, 21);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(547, 295);
            this.groupBox3.TabIndex = 32;
            this.groupBox3.TabStop = false;
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(303, 134);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(73, 20);
            this.label20.TabIndex = 35;
            this.label20.Text = "Total_Bill";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // main_total_bill
            // 
            this.main_total_bill.Location = new System.Drawing.Point(423, 134);
            this.main_total_bill.Multiline = true;
            this.main_total_bill.Name = "main_total_bill";
            this.main_total_bill.Size = new System.Drawing.Size(100, 28);
            this.main_total_bill.TabIndex = 34;
            this.main_total_bill.TextChanged += new System.EventHandler(this.main_total_bill_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(278, 9);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(103, 20);
            this.label18.TabIndex = 33;
            this.label18.Text = "Salesman_Id";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // salesman_id
            // 
            this.salesman_id.Location = new System.Drawing.Point(468, 9);
            this.salesman_id.Multiline = true;
            this.salesman_id.Name = "salesman_id";
            this.salesman_id.Size = new System.Drawing.Size(55, 28);
            this.salesman_id.TabIndex = 25;
            this.salesman_id.TextChanged += new System.EventHandler(this.salesman_id_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(26, 186);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 20);
            this.label15.TabIndex = 30;
            this.label15.Text = "Cash_Paid";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // main_cash
            // 
            this.main_cash.Location = new System.Drawing.Point(149, 178);
            this.main_cash.Multiline = true;
            this.main_cash.Name = "main_cash";
            this.main_cash.Size = new System.Drawing.Size(100, 28);
            this.main_cash.TabIndex = 31;
            this.main_cash.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(26, 220);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 20);
            this.label11.TabIndex = 20;
            this.label11.Text = "Due_amount";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd-MM-yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(45, 266);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(86, 20);
            this.dateTimePicker1.TabIndex = 23;
            this.dateTimePicker1.Value = new System.DateTime(2016, 4, 30, 0, 0, 0, 0);
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(-4, 266);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 20);
            this.label12.TabIndex = 22;
            this.label12.Text = "Date";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(23, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "Quantity";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // main_due
            // 
            this.main_due.Location = new System.Drawing.Point(149, 212);
            this.main_due.Multiline = true;
            this.main_due.Name = "main_due";
            this.main_due.Size = new System.Drawing.Size(100, 28);
            this.main_due.TabIndex = 21;
            this.main_due.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(26, 152);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 20);
            this.label9.TabIndex = 17;
            this.label9.Text = "Net_Bill";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.saved);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(307, 212);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(216, 73);
            this.groupBox4.TabIndex = 29;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Operations";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // saved
            // 
            this.saved.BackColor = System.Drawing.Color.White;
            this.saved.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saved.Location = new System.Drawing.Point(22, 30);
            this.saved.Name = "saved";
            this.saved.Size = new System.Drawing.Size(75, 37);
            this.saved.TabIndex = 28;
            this.saved.Text = "Saved";
            this.saved.UseVisualStyleBackColor = false;
            this.saved.Click += new System.EventHandler(this.saved_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(119, 30);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 37);
            this.button2.TabIndex = 26;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // sales_return_discount
            // 
            this.sales_return_discount.Location = new System.Drawing.Point(149, 110);
            this.sales_return_discount.Multiline = true;
            this.sales_return_discount.Name = "sales_return_discount";
            this.sales_return_discount.Size = new System.Drawing.Size(100, 28);
            this.sales_return_discount.TabIndex = 15;
            this.sales_return_discount.TextChanged += new System.EventHandler(this.sales_return_discount_TextChanged);
            this.sales_return_discount.MouseHover += new System.EventHandler(this.sales_return_discount_MouseHover);
            // 
            // main_bill
            // 
            this.main_bill.Location = new System.Drawing.Point(149, 144);
            this.main_bill.Multiline = true;
            this.main_bill.Name = "main_bill";
            this.main_bill.Size = new System.Drawing.Size(100, 28);
            this.main_bill.TabIndex = 16;
            this.main_bill.TextChanged += new System.EventHandler(this.main_bill_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Discount";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1006, 319);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Reports";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(49, 392);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.White;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.Size = new System.Drawing.Size(1003, 201);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // sales_return
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 605);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "sales_return";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "sales_return";
            this.Load += new System.EventHandler(this.sales_return_Load);
            this.groupBox1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label product_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox invoice_no;
        private System.Windows.Forms.TextBox detail_unit_price;
        private System.Windows.Forms.TextBox main_quantity;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox main_due;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox main_bill;
        private System.Windows.Forms.TextBox sales_return_discount;
        private System.Windows.Forms.TextBox detail_bill;
        private System.Windows.Forms.TextBox salesman_id;
        private System.Windows.Forms.Button saved;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox main_cash;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox detail_quantity;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox invoice_detail;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox return_detail_id;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox salesman_detail_name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox main_return_id;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label detail_discount;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label check_quantity;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox main_total_bill;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox detail_check_discount;
    }
}