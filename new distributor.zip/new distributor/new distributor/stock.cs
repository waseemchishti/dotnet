﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;

namespace new_distributor
{
    public partial class stock : Form
    {
        public stock()
        {
            InitializeComponent();
        }
        BAL bl = new BAL();
        string id;
        private void button1_Click(object sender, EventArgs e)
        {
            stock_id_search();
            bl.stock_insert(stock_id.Text,id, quantity.Text, unit_price.Text);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            bl.stock_delete(stock_id.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bl.stock_update(stock_id.Text, id, quantity.Text, unit_price.Text);
        }
        
        //close.......button......
        
        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void stock_Load(object sender, EventArgs e)
        {
            stock_id_search();
            get_p_name();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = bl.stock_search(stock_id.Text);
            dataGridView1.DataSource = dt;
        }
        //loading stock_id...........
        private void stock_id_search()
        {
            DataTable dt = new DataTable();
            dt = bl.stock_id_search();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    comboBox2.Items.Add(dt.Rows[i].ItemArray[0].ToString());

                }

            }
        }

        //loading  product name in comboBox.............
        //.............................................
        //..........................................
        private void get_p_name()
        {

            DataTable tb = new DataTable();
            tb = bl.p_search_name();
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    comboBox1.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                }
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            id = bl.get_p_id(comboBox1.Text).Rows[0].ItemArray[0].ToString();
            
            lbpid.Text = id.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
