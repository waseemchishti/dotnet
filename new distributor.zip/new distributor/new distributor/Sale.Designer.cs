﻿namespace new_distributor
{
    partial class Sale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lbrows = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbquantity = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtsaleid = new System.Windows.Forms.TextBox();
            this.txtbill = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbproname = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lbpid = new System.Windows.Forms.Label();
            this.btnsdadd = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtinvoiceno = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtuprice = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbsmname = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtcpaid = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txtdamount = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtinvoice = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtnbill = new System.Windows.Forms.TextBox();
            this.txttquantity = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtdiscount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txttbill = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lbrows);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(960, 516);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sale ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lbrows
            // 
            this.lbrows.AutoSize = true;
            this.lbrows.BackColor = System.Drawing.Color.White;
            this.lbrows.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbrows.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbrows.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbrows.Location = new System.Drawing.Point(350, 282);
            this.lbrows.Name = "lbrows";
            this.lbrows.Size = new System.Drawing.Size(21, 22);
            this.lbrows.TabIndex = 41;
            this.lbrows.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(67, 282);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(259, 22);
            this.label14.TabIndex = 40;
            this.label14.Text = "Number of Product Added To Cart :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(57, 313);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(858, 187);
            this.dataGridView1.TabIndex = 39;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.lbquantity);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.txtsaleid);
            this.groupBox2.Controls.Add(this.txtbill);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.cbproname);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.lbpid);
            this.groupBox2.Controls.Add(this.btnsdadd);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtinvoiceno);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtquantity);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.txtuprice);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(556, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(359, 266);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Sale Detail";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // lbquantity
            // 
            this.lbquantity.BackColor = System.Drawing.Color.White;
            this.lbquantity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbquantity.ForeColor = System.Drawing.Color.DarkRed;
            this.lbquantity.Location = new System.Drawing.Point(280, 126);
            this.lbquantity.Name = "lbquantity";
            this.lbquantity.Size = new System.Drawing.Size(15, 22);
            this.lbquantity.TabIndex = 62;
            this.lbquantity.Click += new System.EventHandler(this.lbquantity_Click);
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(21, 24);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(120, 23);
            this.label15.TabIndex = 61;
            this.label15.Text = "Sale Detail ID:";
            // 
            // txtsaleid
            // 
            this.txtsaleid.BackColor = System.Drawing.Color.White;
            this.txtsaleid.Location = new System.Drawing.Point(157, 19);
            this.txtsaleid.Name = "txtsaleid";
            this.txtsaleid.Size = new System.Drawing.Size(112, 26);
            this.txtsaleid.TabIndex = 59;
            // 
            // txtbill
            // 
            this.txtbill.Location = new System.Drawing.Point(157, 191);
            this.txtbill.Name = "txtbill";
            this.txtbill.Size = new System.Drawing.Size(112, 26);
            this.txtbill.TabIndex = 58;
            this.txtbill.TextChanged += new System.EventHandler(this.txtbill_TextChanged);
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(21, 92);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 23);
            this.label12.TabIndex = 51;
            this.label12.Text = "Product Name";
            // 
            // cbproname
            // 
            this.cbproname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbproname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbproname.BackColor = System.Drawing.Color.White;
            this.cbproname.FormattingEnabled = true;
            this.cbproname.Location = new System.Drawing.Point(157, 86);
            this.cbproname.Name = "cbproname";
            this.cbproname.Size = new System.Drawing.Size(112, 28);
            this.cbproname.TabIndex = 56;
            this.cbproname.SelectedIndexChanged += new System.EventHandler(this.cbproname_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 194);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 20);
            this.label9.TabIndex = 57;
            this.label9.Text = " Bill";
            // 
            // lbpid
            // 
            this.lbpid.BackColor = System.Drawing.Color.White;
            this.lbpid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbpid.ForeColor = System.Drawing.Color.DarkRed;
            this.lbpid.Location = new System.Drawing.Point(280, 89);
            this.lbpid.Name = "lbpid";
            this.lbpid.Size = new System.Drawing.Size(15, 22);
            this.lbpid.TabIndex = 53;
            this.lbpid.Click += new System.EventHandler(this.lbpid_Click);
            // 
            // btnsdadd
            // 
            this.btnsdadd.BackColor = System.Drawing.Color.White;
            this.btnsdadd.Location = new System.Drawing.Point(84, 226);
            this.btnsdadd.Name = "btnsdadd";
            this.btnsdadd.Size = new System.Drawing.Size(211, 36);
            this.btnsdadd.TabIndex = 55;
            this.btnsdadd.Text = "Add To Cart";
            this.btnsdadd.UseVisualStyleBackColor = false;
            this.btnsdadd.Click += new System.EventHandler(this.btnsdadd_Click);
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(21, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 23);
            this.label11.TabIndex = 37;
            this.label11.Text = "Invoice No:";
            // 
            // txtinvoiceno
            // 
            this.txtinvoiceno.BackColor = System.Drawing.Color.White;
            this.txtinvoiceno.Location = new System.Drawing.Point(157, 53);
            this.txtinvoiceno.Name = "txtinvoiceno";
            this.txtinvoiceno.Size = new System.Drawing.Size(112, 26);
            this.txtinvoiceno.TabIndex = 42;
            this.txtinvoiceno.TextChanged += new System.EventHandler(this.txtinvoiceno_TextChanged_1);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(21, 128);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 23);
            this.label13.TabIndex = 39;
            this.label13.Text = "Quantity:";
            // 
            // txtquantity
            // 
            this.txtquantity.BackColor = System.Drawing.Color.White;
            this.txtquantity.Location = new System.Drawing.Point(157, 123);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(112, 26);
            this.txtquantity.TabIndex = 43;
            this.txtquantity.TextChanged += new System.EventHandler(this.txtquantity_TextChanged);
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(21, 162);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(93, 23);
            this.label16.TabIndex = 41;
            this.label16.Text = "Unit Price:";
            // 
            // txtuprice
            // 
            this.txtuprice.BackColor = System.Drawing.Color.White;
            this.txtuprice.Location = new System.Drawing.Point(157, 157);
            this.txtuprice.Name = "txtuprice";
            this.txtuprice.Size = new System.Drawing.Size(112, 26);
            this.txtuprice.TabIndex = 44;
            this.txtuprice.TextChanged += new System.EventHandler(this.txtuprice_TextChanged_1);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.cbsmname);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.txtcpaid);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtdamount);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtinvoice);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtnbill);
            this.groupBox1.Controls.Add(this.txttquantity);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtdiscount);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txttbill);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(57, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(493, 266);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sale Main";
            // 
            // cbsmname
            // 
            this.cbsmname.FormattingEnabled = true;
            this.cbsmname.Location = new System.Drawing.Point(355, 58);
            this.cbsmname.Name = "cbsmname";
            this.cbsmname.Size = new System.Drawing.Size(104, 28);
            this.cbsmname.TabIndex = 43;
            this.cbsmname.SelectedIndexChanged += new System.EventHandler(this.cbsmname_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label17.Location = new System.Drawing.Point(230, 123);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(25, 22);
            this.label17.TabIndex = 42;
            this.label17.Text = "%";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Location = new System.Drawing.Point(276, 145);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(163, 86);
            this.groupBox3.TabIndex = 41;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Operation";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(81, 37);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(67, 32);
            this.button2.TabIndex = 1;
            this.button2.Text = "Delate";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(13, 37);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtcpaid
            // 
            this.txtcpaid.BackColor = System.Drawing.Color.White;
            this.txtcpaid.Location = new System.Drawing.Point(123, 184);
            this.txtcpaid.Name = "txtcpaid";
            this.txtcpaid.Size = new System.Drawing.Size(100, 26);
            this.txtcpaid.TabIndex = 34;
            this.txtcpaid.TextChanged += new System.EventHandler(this.txtcpaid_TextChanged_1);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(6, 187);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 23);
            this.label10.TabIndex = 33;
            this.label10.Text = "Cash paid:";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(6, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 23);
            this.label6.TabIndex = 36;
            this.label6.Text = "Due Amount:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(355, 26);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(103, 26);
            this.dateTimePicker1.TabIndex = 39;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(6, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 23);
            this.label1.TabIndex = 22;
            this.label1.Text = "Invoice No:";
            // 
            // txtdamount
            // 
            this.txtdamount.BackColor = System.Drawing.Color.White;
            this.txtdamount.Location = new System.Drawing.Point(123, 216);
            this.txtdamount.Name = "txtdamount";
            this.txtdamount.Size = new System.Drawing.Size(100, 26);
            this.txtdamount.TabIndex = 35;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(238, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 23);
            this.label8.TabIndex = 38;
            this.label8.Text = "Sale Man ID :";
            // 
            // txtinvoice
            // 
            this.txtinvoice.BackColor = System.Drawing.Color.White;
            this.txtinvoice.Location = new System.Drawing.Point(123, 28);
            this.txtinvoice.Name = "txtinvoice";
            this.txtinvoice.Size = new System.Drawing.Size(100, 26);
            this.txtinvoice.TabIndex = 27;
            this.txtinvoice.TextChanged += new System.EventHandler(this.txtinvoice_TextChanged);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(238, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 23);
            this.label7.TabIndex = 37;
            this.label7.Text = "Sale Date:";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(6, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 23);
            this.label3.TabIndex = 24;
            this.label3.Text = "Total Quantity:";
            // 
            // txtnbill
            // 
            this.txtnbill.BackColor = System.Drawing.Color.White;
            this.txtnbill.Location = new System.Drawing.Point(123, 156);
            this.txtnbill.Name = "txtnbill";
            this.txtnbill.Size = new System.Drawing.Size(100, 26);
            this.txtnbill.TabIndex = 31;
            this.txtnbill.TextChanged += new System.EventHandler(this.txtnbill_TextChanged);
            // 
            // txttquantity
            // 
            this.txttquantity.BackColor = System.Drawing.Color.White;
            this.txttquantity.Location = new System.Drawing.Point(123, 60);
            this.txttquantity.Name = "txttquantity";
            this.txttquantity.Size = new System.Drawing.Size(100, 26);
            this.txttquantity.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(6, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 23);
            this.label4.TabIndex = 25;
            this.label4.Text = " Net Bill:";
            // 
            // txtdiscount
            // 
            this.txtdiscount.BackColor = System.Drawing.Color.White;
            this.txtdiscount.Location = new System.Drawing.Point(123, 124);
            this.txtdiscount.Name = "txtdiscount";
            this.txtdiscount.Size = new System.Drawing.Size(100, 26);
            this.txtdiscount.TabIndex = 30;
            this.txtdiscount.TextChanged += new System.EventHandler(this.txtdiscount_TextChanged_1);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(6, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 23);
            this.label2.TabIndex = 23;
            this.label2.Text = "Discount:";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(6, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 23);
            this.label5.TabIndex = 26;
            this.label5.Text = "Total Bill:";
            // 
            // txttbill
            // 
            this.txttbill.BackColor = System.Drawing.Color.White;
            this.txttbill.Location = new System.Drawing.Point(123, 92);
            this.txttbill.Name = "txttbill";
            this.txttbill.Size = new System.Drawing.Size(100, 26);
            this.txttbill.TabIndex = 29;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(23, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(968, 542);
            this.tabControl1.TabIndex = 0;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.BackgroundImage = global::new_distributor.Properties.Resources._1456931289_Cancel_Icon;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Location = new System.Drawing.Point(922, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(66, 41);
            this.button3.TabIndex = 1;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // Sale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 570);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Sale";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sale";
            this.Load += new System.EventHandler(this.Sale_Load);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbquantity;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtsaleid;
        private System.Windows.Forms.TextBox txtbill;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbproname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbpid;
        private System.Windows.Forms.Button btnsdadd;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtinvoiceno;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtuprice;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtcpaid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtdamount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtinvoice;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtnbill;
        private System.Windows.Forms.TextBox txttquantity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdiscount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txttbill;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.ComboBox cbsmname;
        private System.Windows.Forms.Label lbrows;
        private System.Windows.Forms.Label label14;
    }
}