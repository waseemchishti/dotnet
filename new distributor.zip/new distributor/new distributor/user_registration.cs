﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;
using System.Threading;
namespace new_distributor
{
    public partial class user_registration : Form
    {
        public user_registration()
        {
            InitializeComponent();
        }
        BAL bl = new BAL();
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bl.Login_insert(textBox1.Text, textBox2.Text, textBox3.Text, comboBox1.Text);
            MessageBox.Show("You are successfully Registereds");
            Login log = new Login();
            this.Hide();
            log.Show();
           
        }

        private void user_registration_Load(object sender, EventArgs e)
        {
            
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
         dt=   bl.login_status_check(textBox1.Text);
         if (dt.Rows.Count > 0)
         {
             MessageBox.Show("Please enter other user name","Already Exists",MessageBoxButtons.OK,MessageBoxIcon.Error);
             textBox1.Text="";
            
            
         }
         //, 520, 286,   177, 43
         //int check = 0;
         //if (check == 0)
         //{
         //    for (int i = 43; i <= 286; i++)
         //    {
         //        this.Size = new Size(520, i);
         //        Thread.Sleep(15);

         //    }
         //    check = 1;
         //}

         //else if (check == 1)
         //{
         //    for (int i = 286; i >=43 ; i--)
         //    {
         //        this.Size = new Size(520, i);
         //        Thread.Sleep(5);
         //    }
         //    check = 0;
         //}
        
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           

            if(comboBox1.Text== "Administrator"){
                textBox3.Text=1.ToString();
          
            }
            else if(comboBox1.Text=="Company")
            {
            textBox3.Text=2.ToString();
            }
            else if(comboBox1.Text=="Salesman")
                 {
            textBox3.Text=3.ToString();
            }
            else if(comboBox1.Text=="Local")
                 {
            textBox3.Text=4.ToString();
            }
            int check = 0;
            if (check == 0)
            {
                for (int i = 218; i <= 327; i++)
                {
                    this.Size = new Size(520, i);
                    Thread.Sleep(15);

                }
                check = 1;
            }

            else if (check == 1)
            {
                for (int i = 327; i >= 218; i--)
                {
                    this.Size = new Size(520, i);
                    Thread.Sleep(5);
                }
                check = 0;
            }
            button1.Visible = true;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login log = new Login();
            log.Show();

        }
    }
}
