﻿namespace new_distributor
{
    partial class purchase_return
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.product_id = new System.Windows.Forms.TextBox();
            this.Check = new System.Windows.Forms.Button();
            this.detail_quantity_check = new System.Windows.Forms.Label();
            this.detail_check_discount = new System.Windows.Forms.Label();
            this.p_i_search = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.detail_quantity = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.detail_invoice = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.detail_id = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.detail_combo = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.detail_unitprice = new System.Windows.Forms.TextBox();
            this.detail_bill = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.main_total_bill = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.main_quantity = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.main_return_id = new System.Windows.Forms.TextBox();
            this.company_id = new System.Windows.Forms.TextBox();
            this.main_invoice = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.main_cash = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.main_due = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.main_discount = new System.Windows.Forms.TextBox();
            this.main_bill = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(14, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1217, 379);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.BackgroundImage = global::new_distributor.Properties.Resources._1456931289_Cancel_Icon;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(1138, -2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(62, 37);
            this.button3.TabIndex = 35;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(13, 19);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1191, 364);
            this.tabControl1.TabIndex = 33;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1183, 338);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Purchase_Return";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button1);
            this.groupBox7.Controls.Add(this.product_id);
            this.groupBox7.Controls.Add(this.Check);
            this.groupBox7.Controls.Add(this.detail_quantity_check);
            this.groupBox7.Controls.Add(this.detail_check_discount);
            this.groupBox7.Controls.Add(this.p_i_search);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.detail_quantity);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.detail_invoice);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Controls.Add(this.detail_id);
            this.groupBox7.Controls.Add(this.button6);
            this.groupBox7.Controls.Add(this.detail_combo);
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.detail_unitprice);
            this.groupBox7.Controls.Add(this.detail_bill);
            this.groupBox7.Controls.Add(this.label36);
            this.groupBox7.Controls.Add(this.label37);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(635, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(526, 328);
            this.groupBox7.TabIndex = 34;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Detail";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(355, 184);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 29);
            this.button1.TabIndex = 45;
            this.button1.Text = "Discount";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // product_id
            // 
            this.product_id.Location = new System.Drawing.Point(324, 79);
            this.product_id.Multiline = true;
            this.product_id.Name = "product_id";
            this.product_id.Size = new System.Drawing.Size(33, 28);
            this.product_id.TabIndex = 44;
            this.product_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.product_id.TextChanged += new System.EventHandler(this.product_id_TextChanged_1);
            // 
            // Check
            // 
            this.Check.BackColor = System.Drawing.Color.White;
            this.Check.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check.Location = new System.Drawing.Point(80, 271);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(108, 48);
            this.Check.TabIndex = 43;
            this.Check.Text = "Check";
            this.Check.UseVisualStyleBackColor = false;
            this.Check.Click += new System.EventHandler(this.Check_Click);
            // 
            // detail_quantity_check
            // 
            this.detail_quantity_check.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.detail_quantity_check.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detail_quantity_check.Location = new System.Drawing.Point(324, 113);
            this.detail_quantity_check.Name = "detail_quantity_check";
            this.detail_quantity_check.Size = new System.Drawing.Size(33, 25);
            this.detail_quantity_check.TabIndex = 41;
            this.detail_quantity_check.Click += new System.EventHandler(this.detail_quantity_check_Click);
            // 
            // detail_check_discount
            // 
            this.detail_check_discount.AutoSize = true;
            this.detail_check_discount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detail_check_discount.Location = new System.Drawing.Point(353, 232);
            this.detail_check_discount.Name = "detail_check_discount";
            this.detail_check_discount.Size = new System.Drawing.Size(115, 15);
            this.detail_check_discount.TabIndex = 40;
            this.detail_check_discount.Text = "Discounted_Person";
            this.detail_check_discount.Visible = false;
            // 
            // p_i_search
            // 
            this.p_i_search.Location = new System.Drawing.Point(371, 17);
            this.p_i_search.Multiline = true;
            this.p_i_search.Name = "p_i_search";
            this.p_i_search.Size = new System.Drawing.Size(91, 28);
            this.p_i_search.TabIndex = 38;
            this.p_i_search.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(353, 46);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(132, 15);
            this.label30.TabIndex = 37;
            this.label30.Text = "Item_Return_Id search";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(22, 118);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(68, 20);
            this.label31.TabIndex = 32;
            this.label31.Text = "Quantity";
            // 
            // detail_quantity
            // 
            this.detail_quantity.Location = new System.Drawing.Point(201, 111);
            this.detail_quantity.Multiline = true;
            this.detail_quantity.Name = "detail_quantity";
            this.detail_quantity.Size = new System.Drawing.Size(116, 28);
            this.detail_quantity.TabIndex = 31;
            this.detail_quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detail_quantity.TextChanged += new System.EventHandler(this.detail_quantity_TextChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(22, 24);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(88, 20);
            this.label32.TabIndex = 30;
            this.label32.Text = "Invoice_No";
            // 
            // detail_invoice
            // 
            this.detail_invoice.Location = new System.Drawing.Point(201, 16);
            this.detail_invoice.Multiline = true;
            this.detail_invoice.Name = "detail_invoice";
            this.detail_invoice.Size = new System.Drawing.Size(116, 28);
            this.detail_invoice.TabIndex = 30;
            this.detail_invoice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detail_invoice.TextChanged += new System.EventHandler(this.detail_invoice_TextChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(22, 53);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(81, 20);
            this.label33.TabIndex = 29;
            this.label33.Text = "Return_Id";
            // 
            // detail_id
            // 
            this.detail_id.Location = new System.Drawing.Point(201, 47);
            this.detail_id.Multiline = true;
            this.detail_id.Name = "detail_id";
            this.detail_id.Size = new System.Drawing.Size(116, 28);
            this.detail_id.TabIndex = 28;
            this.detail_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detail_id.TextChanged += new System.EventHandler(this.detail_id_TextChanged);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(80, 219);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(237, 48);
            this.button6.TabIndex = 0;
            this.button6.Text = "Add To Cart";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // detail_combo
            // 
            this.detail_combo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.detail_combo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.detail_combo.FormattingEnabled = true;
            this.detail_combo.Location = new System.Drawing.Point(201, 79);
            this.detail_combo.Name = "detail_combo";
            this.detail_combo.Size = new System.Drawing.Size(116, 28);
            this.detail_combo.TabIndex = 11;
            this.detail_combo.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(22, 84);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(115, 20);
            this.label34.TabIndex = 2;
            this.label34.Text = "Product_Name";
            // 
            // detail_unitprice
            // 
            this.detail_unitprice.Location = new System.Drawing.Point(201, 143);
            this.detail_unitprice.Multiline = true;
            this.detail_unitprice.Name = "detail_unitprice";
            this.detail_unitprice.Size = new System.Drawing.Size(116, 28);
            this.detail_unitprice.TabIndex = 13;
            this.detail_unitprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detail_unitprice.TextChanged += new System.EventHandler(this.detail_unitprice_TextChanged);
            // 
            // detail_bill
            // 
            this.detail_bill.Location = new System.Drawing.Point(201, 177);
            this.detail_bill.Multiline = true;
            this.detail_bill.Name = "detail_bill";
            this.detail_bill.Size = new System.Drawing.Size(116, 28);
            this.detail_bill.TabIndex = 14;
            this.detail_bill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.detail_bill.TextChanged += new System.EventHandler(this.detail_bill_TextChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(22, 155);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(82, 20);
            this.label36.TabIndex = 8;
            this.label36.Text = "Unit_Price";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(23, 185);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(29, 20);
            this.label37.TabIndex = 7;
            this.label37.Text = "Bill";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.comboBox3);
            this.groupBox5.Controls.Add(this.main_total_bill);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.main_quantity);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.main_return_id);
            this.groupBox5.Controls.Add(this.company_id);
            this.groupBox5.Controls.Add(this.main_invoice);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.main_cash);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.dateTimePicker2);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.main_due);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.main_discount);
            this.groupBox5.Controls.Add(this.main_bill);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(3, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(626, 328);
            this.groupBox5.TabIndex = 33;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Main";
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(408, 16);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(140, 28);
            this.comboBox3.TabIndex = 36;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // main_total_bill
            // 
            this.main_total_bill.Location = new System.Drawing.Point(417, 81);
            this.main_total_bill.Multiline = true;
            this.main_total_bill.Name = "main_total_bill";
            this.main_total_bill.Size = new System.Drawing.Size(131, 28);
            this.main_total_bill.TabIndex = 34;
            this.main_total_bill.ModifiedChanged += new System.EventHandler(this.textBox1_ModifiedChanged);
            this.main_total_bill.TextChanged += new System.EventHandler(this.main_total_bill_TextChanged_1);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(36, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 20);
            this.label12.TabIndex = 5;
            this.label12.Text = "Invoice_No";
            // 
            // main_quantity
            // 
            this.main_quantity.Location = new System.Drawing.Point(175, 87);
            this.main_quantity.Multiline = true;
            this.main_quantity.Name = "main_quantity";
            this.main_quantity.Size = new System.Drawing.Size(116, 28);
            this.main_quantity.TabIndex = 12;
            this.main_quantity.TextChanged += new System.EventHandler(this.main_quantity_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(413, 47);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(125, 20);
            this.label16.TabIndex = 33;
            this.label16.Text = "Company_name";
            // 
            // main_return_id
            // 
            this.main_return_id.Location = new System.Drawing.Point(175, 50);
            this.main_return_id.Multiline = true;
            this.main_return_id.Name = "main_return_id";
            this.main_return_id.Size = new System.Drawing.Size(116, 28);
            this.main_return_id.TabIndex = 10;
            // 
            // company_id
            // 
            this.company_id.Location = new System.Drawing.Point(554, 18);
            this.company_id.Multiline = true;
            this.company_id.Name = "company_id";
            this.company_id.Size = new System.Drawing.Size(18, 26);
            this.company_id.TabIndex = 25;
            this.company_id.TextChanged += new System.EventHandler(this.company_id_TextChanged);
            // 
            // main_invoice
            // 
            this.main_invoice.Location = new System.Drawing.Point(175, 16);
            this.main_invoice.Multiline = true;
            this.main_invoice.Name = "main_invoice";
            this.main_invoice.Size = new System.Drawing.Size(116, 28);
            this.main_invoice.TabIndex = 9;
            this.main_invoice.TextChanged += new System.EventHandler(this.main_invoice_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(31, 193);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(86, 20);
            this.label17.TabIndex = 30;
            this.label17.Text = "Cash_Paid";
            // 
            // main_cash
            // 
            this.main_cash.Location = new System.Drawing.Point(175, 185);
            this.main_cash.Multiline = true;
            this.main_cash.Name = "main_cash";
            this.main_cash.Size = new System.Drawing.Size(116, 28);
            this.main_cash.TabIndex = 31;
            this.main_cash.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(34, 227);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(102, 20);
            this.label19.TabIndex = 20;
            this.label19.Text = "Due_amount";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "dd-MM-yyyy";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(38, 274);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(100, 26);
            this.dateTimePicker2.TabIndex = 23;
            this.dateTimePicker2.Value = new System.DateTime(2016, 4, 30, 0, 0, 0, 0);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(34, 89);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(68, 20);
            this.label22.TabIndex = 6;
            this.label22.Text = "Quantity";
            // 
            // main_due
            // 
            this.main_due.Location = new System.Drawing.Point(175, 219);
            this.main_due.Multiline = true;
            this.main_due.Name = "main_due";
            this.main_due.Size = new System.Drawing.Size(116, 28);
            this.main_due.TabIndex = 21;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(34, 159);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(63, 20);
            this.label23.TabIndex = 17;
            this.label23.Text = "Net_Bill";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Peru;
            this.groupBox6.Controls.Add(this.button4);
            this.groupBox6.Controls.Add(this.button5);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(358, 212);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(242, 88);
            this.groupBox6.TabIndex = 29;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Operations";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(26, 30);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 37);
            this.button4.TabIndex = 28;
            this.button4.Text = "Saved";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            this.button4.Enter += new System.EventHandler(this.button4_Enter);
            this.button4.MouseLeave += new System.EventHandler(this.button4_MouseLeave);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(139, 30);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(87, 37);
            this.button5.TabIndex = 26;
            this.button5.Text = "Search";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // main_discount
            // 
            this.main_discount.Location = new System.Drawing.Point(175, 117);
            this.main_discount.Multiline = true;
            this.main_discount.Name = "main_discount";
            this.main_discount.Size = new System.Drawing.Size(116, 28);
            this.main_discount.TabIndex = 15;
            this.main_discount.TextChanged += new System.EventHandler(this.main_discount_TextChanged);
            // 
            // main_bill
            // 
            this.main_bill.Location = new System.Drawing.Point(175, 151);
            this.main_bill.Multiline = true;
            this.main_bill.Name = "main_bill";
            this.main_bill.Size = new System.Drawing.Size(116, 28);
            this.main_bill.TabIndex = 16;
            this.main_bill.TextChanged += new System.EventHandler(this.main_total_bill_TextChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(34, 122);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(72, 20);
            this.label24.TabIndex = 4;
            this.label24.Text = "Discount";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(338, 87);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(73, 20);
            this.label25.TabIndex = 35;
            this.label25.Text = "Total_Bill";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(34, 54);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(81, 20);
            this.label26.TabIndex = 1;
            this.label26.Text = "Return_Id";
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1183, 338);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Reports";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(27, 393);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Size = new System.Drawing.Size(1191, 195);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // purchase_return
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.ClientSize = new System.Drawing.Size(1227, 589);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "purchase_return";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "purchase_return";
            this.Load += new System.EventHandler(this.purchase_return_Load);
            this.groupBox1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label detail_quantity_check;
        private System.Windows.Forms.Label detail_check_discount;
        private System.Windows.Forms.TextBox p_i_search;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox detail_quantity;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox detail_invoice;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox detail_id;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ComboBox detail_combo;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox detail_unitprice;
        private System.Windows.Forms.TextBox detail_bill;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox main_total_bill;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox main_quantity;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox main_return_id;
        private System.Windows.Forms.TextBox company_id;
        private System.Windows.Forms.TextBox main_invoice;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox main_cash;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox main_due;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox main_discount;
        private System.Windows.Forms.TextBox main_bill;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Check;
        private System.Windows.Forms.TextBox product_id;
        private System.Windows.Forms.Button button1;

    }
}