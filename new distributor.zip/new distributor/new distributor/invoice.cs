﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace new_distributor
{
    public partial class invoice : Form
    {
        public invoice()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=desktop-lc4ovj7\sqlexpress;Initial Catalog=awan_distributor;Integrated Security=True");
        private void invoice_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("invoice", con);
            cmd.CommandType = CommandType.StoredProcedure;
        
           SqlDataAdapter ds = new SqlDataAdapter(cmd);
           DataTable dt = new DataTable();
           ds.Fill(dt);
           if (dt.Rows.Count > 0)
           {
               for(int i=0; i<dt.Rows.Count;i++)
               {
                   textBox1.Text = (dt.Rows[i].ItemArray[0].ToString());
                   int a = Convert.ToInt16(textBox1.Text);
                   int b = 1;
                   int c = a + b;
                   textBox2.Text = c.ToString();
                   

               }

           }

        }
       
    }
}
