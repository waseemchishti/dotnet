﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;



namespace new_distributor.data_access
{
    class DAL
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-53MEJC5;Initial Catalog=awan_distributor;Integrated Security=True");


        #region category
        //insert
        public DataTable c_insert(string name, string des)
        {
            SqlCommand cmd = new SqlCommand("insert_cat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@cat_id", id);
            cmd.Parameters.AddWithValue("@cat_name", name);
            cmd.Parameters.AddWithValue("@cat_des", des);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }
        //delete category........

        public void c_delete(string id)
        {
            SqlCommand cmd = new SqlCommand("del_cat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@cat_id", id);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
        //update category..........................
        //...........................................
        public void c_update(string id, string name, string des)
        {
            SqlCommand cmd = new SqlCommand("up_cat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@cat_id", id);
            cmd.Parameters.AddWithValue("@cat_name", name);
            cmd.Parameters.AddWithValue("@cat_des", des);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();



        }
        // search category.......

        public DataTable c_search(string id)
        {
            SqlCommand cmd = new SqlCommand("search_cat", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@cat_id", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }
        // loading category name by id................
        public DataTable c_search_name()
        {
            SqlCommand cmd = new SqlCommand("search_cat_name", con);
            cmd.CommandType = CommandType.StoredProcedure;
           SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        // loading category name by id type................
        public DataTable c_search_name_type(string id)
        {
            SqlCommand cmd = new SqlCommand("category_name_type", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        //loading category_id...............
        public DataTable category_id()
        {
            SqlCommand cmd = new SqlCommand("category_id", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        //cat id check......
        public DataTable category_id_check(string id)
        {
            SqlCommand cmd = new SqlCommand("category_id_check", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }

        //searching category byname in comboBox..........
        public DataTable c_byname(string name)
        {
            SqlCommand cmd = new SqlCommand("cat_byname", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@catname", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;



        }
        //get category_id By name...............................
        public DataTable get_id(string name)
        {

            SqlCommand cmd = new SqlCommand("get_cat_id", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@cat", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        #endregion

        #region product
        //insert product...........

        public void p_insert(string id, string name, string type, string c_id, string up)
        {
            SqlCommand cmd = new SqlCommand("insert_product", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@p_id", id);
            cmd.Parameters.AddWithValue("@p_name", name);
            cmd.Parameters.AddWithValue("@p_type", type);
            cmd.Parameters.AddWithValue("@cat_id", c_id);
            cmd.Parameters.AddWithValue("@unit_p", up);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        //delete product........

        public void p_delete(string id)
        {
            SqlCommand cmd = new SqlCommand("delete_product", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@p_id", id);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }

        public void p_update(string id, string name, string type, string c_id, string up)
        {
            SqlCommand cmd = new SqlCommand("up_p", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@p_id", id);
            cmd.Parameters.AddWithValue("@p_name", name);
            cmd.Parameters.AddWithValue("@p_type", type);
            cmd.Parameters.AddWithValue("@cat_id", c_id);
            cmd.Parameters.AddWithValue("@unit_p", up);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public DataTable p_search(string id)
        {
            SqlCommand cmd = new SqlCommand("search_product", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@p_id", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }
        //loading product id..........
        public DataTable product_id()
        {
            SqlCommand cmd = new SqlCommand("product_id", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }
        // loading products by name.................
        public DataTable p_search_name()
        {
            SqlCommand cmd = new SqlCommand("search_p_name", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;



        }
        //searching product byname in comboBox..........
        public DataTable p_byname(string name)
        {
            SqlCommand cmd = new SqlCommand("p_byname", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@pname", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;



        }
        //get product_id By name...............................
        public DataTable get_p_id(string name)
        {

            SqlCommand cmd = new SqlCommand("get_p_id", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@p", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        // loading products type in combo box in product page...............

        public DataTable get_type()
        {
            SqlCommand cmd = new SqlCommand("get_product_type", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        //getting category id from product type.........in product table....
        public DataTable get_cat_id_from_type(string type)
        {
            SqlCommand cmd = new SqlCommand("cat_id_from_type", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name",type);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }
        #endregion
        // product type.................

        #region product type..
        //insert type,..........
        public DataTable p_t_insert(string type, string c_id)
        {
            SqlCommand cmd = new SqlCommand("type_insert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@type_name", type);
            cmd.Parameters.AddWithValue("@cat_id", c_id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }
        //delete type........

        public void type_delete(string name)
        {
            SqlCommand cmd = new SqlCommand("type_delete", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@type_name", name);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
        //update type..........................
        //...........................................
        public void type_update(string type, string c_id)
        {
            SqlCommand cmd = new SqlCommand("type_update", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@type_name", type);
            cmd.Parameters.AddWithValue("@cat_id", c_id);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            //SqlDataAdapter ds = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable();
            //ds.Fill(dt);
            //return dt;
        }
        // search type..........

        public DataTable type_search(string name)
        {
            SqlCommand cmd = new SqlCommand("type_dearch", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@type_name", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }
   

        #endregion

        #region company...
        public DataTable com_insert(string id, string name, string ph, string mob, string email, string add, string city, string due)
        {
            SqlCommand cmd = new SqlCommand("company_insert_duplicationnn", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@com_id", id);
            cmd.Parameters.AddWithValue("@com_name", name);
            cmd.Parameters.AddWithValue("@com_phone", ph);
            cmd.Parameters.AddWithValue("@com_mobile", mob);
            cmd.Parameters.AddWithValue("@com_email", email);
            cmd.Parameters.AddWithValue("@com_city", add);
            cmd.Parameters.AddWithValue("@com_add", city);
            cmd.Parameters.AddWithValue("@com_due", due);

            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }
        //delete company........

        public void com_delete(string id)
        {
            SqlCommand cmd = new SqlCommand("company_delete", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@com_id", id);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
        //update company..........................
        //...........................................
        public DataTable com_update(string id, string name, string ph, string mob, string email, string add, string city, string due)
        {
            SqlCommand cmd = new SqlCommand("company_update", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@com_id", id);
            cmd.Parameters.AddWithValue("@com_name", name);
            cmd.Parameters.AddWithValue("@com_phone", ph);
            cmd.Parameters.AddWithValue("@com_mobile", mob);
            cmd.Parameters.AddWithValue("@com_email", email);
            cmd.Parameters.AddWithValue("@com_city", add);
            cmd.Parameters.AddWithValue("@com_add", city);
            cmd.Parameters.AddWithValue("@com_due", due);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;



        }
        // search company.......

        public DataTable com_search(string id)
        {
            SqlCommand cmd = new SqlCommand("company_search", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@com_id", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }

        //.............select company.....
        public DataTable com_name(string name)
        {

            SqlCommand cmd = new SqlCommand("company_name", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@com_name", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }
        // loading company by name.................
        public DataTable com_loading_name()
        {
            SqlCommand cmd = new SqlCommand("company_loading", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }
        //searching company byname in comboBox..........
        public DataTable com_byname(string name)
        {
            SqlCommand cmd = new SqlCommand("company_byname", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@com_name", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;



        }
        //get company_id By name...............................
        public DataTable get_com_id(string name)
        {

            SqlCommand cmd = new SqlCommand("get_company_id", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@com_name", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        public DataTable compnyname()
        {
            SqlCommand cmd = new SqlCommand("compnyname", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }
        #endregion


        #region salemain biodata
        //insert salesman.............

        public void salesman_insert(string id, string name, string gender, string mob, string email, string city, string add, string salary,string pic, string date)
        {
            SqlCommand cmd = new SqlCommand("salesman_insert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@s_id", id);
            cmd.Parameters.AddWithValue("@s_name", name);
            cmd.Parameters.AddWithValue("@s_gender", gender);
            cmd.Parameters.AddWithValue("@s_mobile", mob);
            cmd.Parameters.AddWithValue("@s_email", email);
            cmd.Parameters.AddWithValue("@s_city", city);
            cmd.Parameters.AddWithValue("@s_address", add);
            cmd.Parameters.AddWithValue("@s_salary", salary);
            cmd.Parameters.AddWithValue("@s_img", pic);
            cmd.Parameters.AddWithValue("@s_date", date);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
        //delete salesman........

        public void salesman_delete(string id)
        {
            SqlCommand cmd = new SqlCommand("salesman_delete", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@s_id", id);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
        //update salesman..........................

        public void smupdate(string sid, string name, string gender, string mob, string email, string city, string add, string salary, string img, string dat, string due)
        {

            SqlCommand cmd = new SqlCommand("smain_update", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@siid", sid);
            cmd.Parameters.AddWithValue("@sname", name);
            cmd.Parameters.AddWithValue("@sgender", gender);
            cmd.Parameters.AddWithValue("@smobile", mob);
            cmd.Parameters.AddWithValue("@semail", email);
            cmd.Parameters.AddWithValue("@scity", city);
            cmd.Parameters.AddWithValue("@saddress", add);
            cmd.Parameters.AddWithValue("@ssalary", salary);
            cmd.Parameters.AddWithValue("@simg", img);
            cmd.Parameters.AddWithValue("@sdate", dat);
            cmd.Parameters.AddWithValue("@due", due);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        // search salesman.......

        public DataTable salesman_search(string id)
        {
            SqlCommand cmd = new SqlCommand("salesman_search", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@s_id", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }
        public DataTable salesmanname()
        {
            SqlCommand cmd = new SqlCommand("salemanname", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }
        // loading salesman id..........
        public DataTable salesmanID()
        {
            SqlCommand cmd = new SqlCommand("salesman_id_get", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }

        #endregion

        #region stock...

        //insert stock........

        public DataTable stock_insert(string id, string pid, string quantity, string unitp)
        {
            SqlCommand cmd = new SqlCommand("stock_insert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@stock_id", id);
            cmd.Parameters.AddWithValue("@product_id", pid);
            cmd.Parameters.AddWithValue("@quantity", quantity);
            cmd.Parameters.AddWithValue("@u_p", unitp);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }
        //delete stock........

        public void stock_delete(string id)
        {
            SqlCommand cmd = new SqlCommand("stock_delete", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@stock_id", id);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }


        //stock search............................................
        //........................................................
        //.............................
        public DataTable stock_search(string id)
        {
            SqlCommand cmd = new SqlCommand("stock_search", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@stock_id", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }

        //update stock..........................
        //...........................................
        public DataTable stock_update(string id, string pid, string quantity, string unitp)
        {
            SqlCommand cmd = new SqlCommand("stock_update", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@stock_id", id);
            cmd.Parameters.AddWithValue("@product_id", pid);
            cmd.Parameters.AddWithValue("@quantity", quantity);
            cmd.Parameters.AddWithValue("@u_p", unitp);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }
        public DataTable stokqpsearch(string id)
        {
            SqlCommand cmd = new SqlCommand("stockqpsearch", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@pid", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }

        //stock id search........................
        public DataTable stock_id_search()
        {
            SqlCommand cmd = new SqlCommand("stock_id", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }


        #endregion
        // sail...............................
        #region sail product


        public void smain_delete(string invoice)
        {
            SqlCommand cmd = new SqlCommand("smaindelete", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@inv", invoice);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }

        public DataTable smain_search(string invoic)
        {
            SqlCommand cmd = new SqlCommand("smainsearch ", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@inv", invoic);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }

        public DataTable smain_datesearch(string date)
        {
            SqlCommand cmd = new SqlCommand("smaindatesearch", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@date", date);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }

        public void smain_dueupdate(string invoice, string cashp, string due)
        {
            SqlCommand cmd = new SqlCommand("smainupdatedue", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@inv", invoice);
            cmd.Parameters.AddWithValue("@cp", cashp);
            cmd.Parameters.AddWithValue("@due", due);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }

        #endregion

        //purchase......
        #region purchases


        #endregion

        // salesreturn...........................
        // loading salesman name.................
        //public DataTable salesman_name()
        //{
        //    SqlCommand cmd = new SqlCommand("loading_salesman_name", con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    SqlDataAdapter ds = new SqlDataAdapter(cmd);
        //    DataTable dt = new DataTable();
        //    ds.Fill(dt);
        //    return dt;

        //}
        //getting invoice #........
        public DataTable salesman_name(string id)
        {
            SqlCommand cmd = new SqlCommand("salesman_name", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@invoice", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        // getting salesman .....id..........
        public DataTable salesman_id(string name)
        {
            SqlCommand cmd = new SqlCommand("salesman_id", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }

        // get quantity,and unit price from sales_detail...............
        public DataTable sales_return_quantity_price(string invoice, string id)
        {
            SqlCommand cmd = new SqlCommand("sales_return_quantity_price", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@invoice", invoice);
            cmd.Parameters.AddWithValue("@id", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        //getting discount from sales main into sales return...............
        public DataTable discount(string invoice)
        {
            SqlCommand cmd = new SqlCommand("discount_get", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@invoice", invoice);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }

        public DataTable sales_return_detail_search(string id)
        {
             SqlCommand cmd=new SqlCommand("sales_return_detail_search",con);
            cmd.CommandType=CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id",id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        
        }
        public DataTable sales_return_main_search(string id)
        {
        SqlCommand cmd=new SqlCommand("sales_return_search",con);
            cmd.CommandType=CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id",id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;
        }




        //login............



        

        public void login_insert(string name, string pasword, string ac) //string at)
        {
            SqlCommand cmd = new SqlCommand("user_login", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@password", pasword);
            cmd.Parameters.AddWithValue("@access_level", ac);
            //cmd.Parameters.AddWithValue("@authorization_level", at);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
        //Login Status................
        public DataTable login_status(string name, string pass, string access)
        {
            SqlCommand cmd = new SqlCommand("login_status", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@password", pass);
            cmd.Parameters.AddWithValue("@access", access);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        public DataTable check_discount(string invoice)
        {
            SqlCommand cmd = new SqlCommand("purchase_discount_check",con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@invoice",invoice);
            SqlDataAdapter ds=new SqlDataAdapter(cmd);
            DataTable dt=new DataTable();
            ds.Fill(dt);
            return dt;

        
        
        }


        //login_status_check....................duplication..........

        public DataTable login_status_check(string name)
        {
            SqlCommand cmd = new SqlCommand("login_status_check", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
        public DataTable login_acces_get(string name)
        {
            SqlCommand cmd = new SqlCommand("login_access_level", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", name);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;

        }
      /////...........................Purchase_Return......................
        public DataTable purchase_quantity_price(string id)
        {
            SqlCommand cmd = new SqlCommand("p_d_r_quantity", con);

            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@invoice", invoice);
            cmd.Parameters.AddWithValue("@id", id);
            //cmd.Parameters.AddWithValue("@pdid", pid);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;



        }
        public DataTable purchase_return_did(string invoice, string id)
        {
            SqlCommand cmd = new SqlCommand("p_r_did", con);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@invoice", invoice);
            cmd.Parameters.AddWithValue("@pid", id);
           
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;



        }
       //.....purchase detail check...
        //..
        ///....
        ///....
        public DataTable pdetail_check(string invoice)
        {
            SqlCommand cmd = new SqlCommand("purchase_detail_check", con);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@invoice", invoice);
             SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }
        public DataTable pdetail_search(string id)
        {
            SqlCommand cmd = new SqlCommand("purchase_return_detail_search", con);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@p_r_id", id);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }

        //...........................OLD purchase check..........

        //.....purchase detail check...
        //..
        ///....
        ///....
        public DataTable Oldp_check(string invoice)
        {
            SqlCommand cmd = new SqlCommand("purchase_detail_check", con);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@invoice", invoice);
            SqlDataAdapter ds = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ds.Fill(dt);
            return dt;


        }
        /***  public DataTable pdetail_search(string id)
          {
              SqlCommand cmd = new SqlCommand("purchase_return_detail_search", con);

              cmd.CommandType = CommandType.StoredProcedure;
              cmd.Parameters.AddWithValue("@p_r_id", id);
              SqlDataAdapter ds = new SqlDataAdapter(cmd);
              DataTable dt = new DataTable();
              ds.Fill(dt);
              return dt;
          ***/




        #region
        //................old_purchase......................


        public void old_purchse_insert(int imei,string pname, string pgender, string pmob, string pcity, string pdate, string pcat, string pbrand, string pmodel,string pprice,string pimage, string mimage)
        {
            SqlCommand cmd = new SqlCommand("purchase_old_insert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@imei", imei);
            cmd.Parameters.AddWithValue("@pname", pname);
            cmd.Parameters.AddWithValue("@pgender", pgender);
            cmd.Parameters.AddWithValue("@pmob", pmob);
            cmd.Parameters.AddWithValue("@pcity", pcity);
            cmd.Parameters.AddWithValue("@pdate", pdate);
            cmd.Parameters.AddWithValue("@pcat", pcat);
            cmd.Parameters.AddWithValue("@pbrand", pbrand);
            cmd.Parameters.AddWithValue("@pmodel", pmodel);
            cmd.Parameters.AddWithValue("@pprice", pprice);
            cmd.Parameters.AddWithValue("@mimage",mimage);
            cmd.Parameters.AddWithValue("@mimage", mimage);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
        #endregion


    }
    
 }