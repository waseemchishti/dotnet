﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using new_distributor.b_l;

namespace new_distributor
{
    public partial class sales_return : Form
    {
        public sales_return()
        {
            InitializeComponent();
        }
        double tbill;
        double bill;
       // double ttbil;
        int quantity;
        int tquantity;
       // int ttquantity;
       
        DataTable dt = new DataTable();
        DataRow dr;
        BAL bl = new BAL();
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-LC4OVJ7\SQLEXPRESS;Initial Catalog=awan_distributor;Integrated Security=True");
        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
           Convert.ToString( dateTimePicker1.Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


            string id;
            string return_quan;
            string return_unit_price;
            id = bl.get_p_id(comboBox1.Text).Rows[0].ItemArray[0].ToString();
            if (bl.get_p_id(comboBox1.Text).Rows.Count > 0)
            {
                product_id.Text = id;

            }


            if (bl.sales_return_quantity_price(invoice_detail.Text, product_id.Text).Rows.Count > 0)
            {
                return_quan = (bl.sales_return_quantity_price(invoice_detail.Text, product_id.Text)).Rows[0].ItemArray[2].ToString();
                return_unit_price = (bl.sales_return_quantity_price(invoice_detail.Text, product_id.Text)).Rows[0].ItemArray[3].ToString();
                check_quantity.Text = return_quan;
                detail_unit_price.Text = return_unit_price;

            }
          
           
        }
        private void get_p_name()
        {

           
            dt = bl.p_search_name();
            if (dt.Rows.Count > 0)
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    comboBox1.Items.Add(dt.Rows[i].ItemArray[0].ToString());
                }
            }

        }
       

        private void sales_return_Load(object sender, EventArgs e)
        {
            get_p_name();
            dt.Columns.Add("Invoice_no");
            dt.Columns.Add("Return_id");
            dt.Columns.Add("Product_id");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Unit_Price");
            dt.Columns.Add("Bill");
            dt.Columns.Add("discount_description");
            //dt.Columns.Add("Discount");
            //dt.Columns.Add("Net_Bill");
            //dt.Columns.Add("Salesman_name");
            //dt.Columns.Add("Due_Amount");
            //dt.Columns.Add("Date");
            
            //salesman_name();
           
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        private void comboBox2_TextChanged(object sender, EventArgs e)
        {
            
        }
      

        private void invoice_no_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bill = Convert.ToDouble(detail_bill.Text);
            tbill = tbill + bill;
            main_total_bill.Text = tbill.ToString();


            quantity = Convert.ToInt32(detail_quantity.Text);
            tquantity += quantity;
            main_quantity.Text = tquantity.ToString();
            
            dr = dt.NewRow();
            dr["Invoice_no"]=invoice_detail.Text.ToString();
            dr["Return_id"]=return_detail_id.Text.ToString();
            dr["Product_id"]=product_id.Text.ToString();
            dr["Quantity"]=detail_quantity.Text.ToString();
            dr["Unit_Price"]=detail_unit_price.Text.ToString();
            dr["Bill"]=detail_bill.Text.ToString();

            if (Convert.ToDouble(detail_check_discount.Text)>=0)
            {
                dr["discount_description"] = detail_discount.Text.ToString();
            }
            
            dt.Rows.Add(dr);
            dataGridView1.DataSource = dt;




            //int a = 0;
            //for (a = 0; a <= dataGridView1.Rows.Count - 1; a++)
            //{
            //    detail_quantity.Text = a.ToString();
            //}
            ////lbrows.Text = dt.Rows.Count.ToString();
            // invoice_detail.Text="";
            // return_detail_id.Text = "";
            // product_id.Text = "";
            // detail_quantity.Text = "";
            // detail_unit_price.Text = "";
            // detail_bill.Text = "";
             //detail_discount.Text = "";
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            
        }
        
     

        private void invoice_detail_TextChanged(object sender, EventArgs e)
        {
            if (invoice_detail.Text == "")
            {

            }
            else
            {

                if (invoice_detail.Text == "")
                {
                    return;
                }
                string name = (bl.salesman_name(invoice_detail.Text).Rows[0].ItemArray[8].ToString());
                salesman_detail_name.Text = name.ToString();
                //txtinvoice.Text = txtinvoiceno.Text;

            }
         
        

        }

       

        private void salesman_id_TextChanged(object sender, EventArgs e)
        {
            string a;
       a= Convert.ToString(invoice_detail.Text);

       invoice_no.Text = a.ToString();
        }

        private void salesman_name_TabIndexChanged(object sender, EventArgs e)
        {
           
        }

       

      

        private void salesman_detail_name_TextChanged_1(object sender, EventArgs e)
        {
            string id;
            id = bl.salesman_id(salesman_detail_name.Text).Rows[0].ItemArray[0].ToString();
            salesman_id.Text = id.ToString();

        }

        private void return_detail_id_TextChanged(object sender, EventArgs e)
        {
            main_return_id.Text = return_detail_id.Text.ToString();
        }

        private void sales_return_discount_TextChanged(object sender, EventArgs e)
        {
           
            if (sales_return_discount.Text == "")
            {

            }
            else
            {

                if (sales_return_discount.Text == "")
                {
                    return;
                }
                double dis = Convert.ToDouble(sales_return_discount.Text);
                double tbill = Convert.ToDouble(main_total_bill.Text);
                double res = (dis / 100) * tbill;
                main_bill.Text = (tbill - res).ToString();

            }
            
        }

        private void comboBox1_MouseHover(object sender, EventArgs e)
        {

        }

        private void detail_quantity_TextChanged(object sender, EventArgs e)
        {
            if (detail_quantity.Text == "")
            {

            }
            else
            {
                main_quantity.Text = detail_quantity.Text;
                if (detail_quantity.Text == "")
                {
                    return;
                }
              
                int cquantity = Convert.ToInt32(check_quantity.Text);
                int dquantity = Convert.ToInt32(detail_quantity.Text);


                if (dquantity > cquantity)
                {
                    MessageBox.Show("Enlisted quantity not Availabel");
                    detail_quantity.Text = "";
                    detail_quantity.Focus();
                    return;
                }

                double q = Convert.ToDouble(detail_quantity.Text);
                double p = Convert.ToDouble(detail_unit_price.Text);
                double res = q * p;
                detail_bill.Text = res.ToString();
            }
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void detail_discount_Click(object sender, EventArgs e)
        {

        }

        private void detail_unit_price_TextChanged(object sender, EventArgs e)
        {

        
        }

        private void main_bill_TextChanged(object sender, EventArgs e)
        {


        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
            if (main_cash.Text == "")
            {

            }
            else
            {

                if (main_cash.Text == "")
                {
                    return;
                }

                double nbil = Convert.ToDouble(main_bill.Text);
                double cashp = Convert.ToDouble(main_cash.Text);
                double res = (nbil - cashp);
                main_due.Text = res.ToString();

            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            //int tqu = Convert.ToInt32(main_quantity.Text);
            //double tttbill = Convert.ToDouble(main_bill.Text);

            //int dgquan = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["Quantity"].Value);
            //double dgbill = Convert.ToDouble(dataGridView1.SelectedRows[0].Cells["Bill"].Value);
            //// MessageBox.Show(dgquan.ToString() +"\n"+dgbill.ToString());
            //ttquantity = (tqu - dgquan);
            //main_quantity.Text = ttquantity.ToString();
            //tquantity = ttquantity;
            ////double bilres = (ttbill - dgbill);
            //ttbil = (tttbill - dgbill);
            //main_bill.Text = ttbil.ToString();
            //tbill = ttbil;
            //dataGridView1.Rows.RemoveAt(0);

            ////lbrows.Text = dataGridView1.Rows.Count.ToString();
        }

        private void check_quantity_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void sales_return_discount_MouseHover(object sender, EventArgs e)
        {
            sales_return_discount.Text = bl.discount(invoice_no.Text).Rows[0].ItemArray[0].ToString();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox1_MouseHover(object sender, EventArgs e)
        {
            detail_check_discount.Text = bl.discount(invoice_no.Text).Rows[0].ItemArray[0].ToString();
            
                detail_discount.Visible = true;
                //sales_return_discount.Text = detail_check_discount.Text;
            
            
        }

        private void saved_Click(object sender, EventArgs e)
        {


            SqlTransaction trans;
            con.Open();
            trans = con.BeginTransaction();

            try
            {
                if (dataGridView1.Rows.Count <= 0)
                {
                    MessageBox.Show("First Add product to cart");
                }



                SqlCommand cmd = new SqlCommand("sales_return_main_insert", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@return_id", main_return_id.Text);
                cmd.Parameters.AddWithValue("@invoice", invoice_no.Text);
                cmd.Parameters.AddWithValue("@quantity", main_quantity.Text);
                cmd.Parameters.AddWithValue("@total_bill", main_total_bill.Text);
                cmd.Parameters.AddWithValue("@net_bill", main_bill.Text);
                cmd.Parameters.AddWithValue("@discount", sales_return_discount.Text);
                cmd.Parameters.AddWithValue("@cash", main_cash.Text);
                cmd.Parameters.AddWithValue("@due", main_due.Text);
                cmd.Parameters.AddWithValue("@salesman_id", salesman_id.Text);
                cmd.Parameters.AddWithValue("@date", dateTimePicker1.Text);
                cmd.Transaction = trans;
                cmd.ExecuteNonQuery();

                //sale main due update



                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {

                    //purchase insert
                    SqlCommand cmdd = new SqlCommand("sales_return_detail_insert", con);
                    cmdd.CommandType = CommandType.StoredProcedure;
                    cmdd.Parameters.AddWithValue("@rid", dataGridView1.Rows[i].Cells["Return_id"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@pid", dataGridView1.Rows[i].Cells["Product_id"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@invoice", dataGridView1.Rows[i].Cells["Invoice_no"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@quantity", dataGridView1.Rows[i].Cells["Quantity"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@up", dataGridView1.Rows[i].Cells["Unit_Price"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@bill", dataGridView1.Rows[i].Cells["Bill"].Value.ToString());
                    cmdd.Parameters.AddWithValue("@discount", dataGridView1.Rows[i].Cells["discount_description"].Value.ToString());


                    cmdd.Transaction = trans;
                    cmdd.ExecuteNonQuery();

                    //quantity update...

                    string quan = dataGridView1.Rows[i].Cells["Quantity"].Value.ToString();
                    //int rs = Convert.ToInt32(quan);
                    string pnam = dataGridView1.Rows[i].Cells["Product_id"].Value.ToString();

                    SqlCommand comand = new SqlCommand("s_r_stock_update", con);
                    comand.CommandType = CommandType.StoredProcedure;
                    comand.Parameters.AddWithValue("@quantity", quan);
                    comand.Parameters.AddWithValue("@id", pnam);
                    comand.Transaction = trans;
                    comand.ExecuteNonQuery();

                }
                //salesman_due update..................


                SqlCommand scomand = new SqlCommand("salesman_due_update", con);
                scomand.CommandType = CommandType.StoredProcedure;
                scomand.Parameters.AddWithValue("@id", salesman_id.Text);
                scomand.Parameters.AddWithValue("@due", main_due.Text);
                scomand.Transaction = trans;
                scomand.ExecuteNonQuery();

                trans.Commit();
                //.....................
                main_return_id.Text = "";
                invoice_no.Text = "";
                main_quantity.Text = "";
                sales_return_discount.Text = "";
                main_bill.Text = "";
                main_cash.Text = "";
                main_due.Text = "";
                main_total_bill.Text = "";

                dataGridView1.DataSource = null;


                con.Close();
            }

            catch (Exception ex)
            {

                trans.Rollback();
                throw ex;
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {
        
        }

        private void main_total_bill_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            search(textBox2.Text);


        }
        public void search(string id)
        {
            DataTable dt = new DataTable();
            dt = bl.sales_return_detail_search(id);
            dataGridView1.DataSource = dt;
        }
        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void product_id_Click(object sender, EventArgs e)
        {

        }

        private void detail_bill_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void main_quantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void main_return_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
          dt= bl.sales_return_main_saerch(main_return_id.Text);


            if (dt.Rows.Count >= 1)
            {
                dataGridView1.DataSource = dt;

            }
            else
            {


                MessageBox.Show("no data found");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        }
    }

