﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;
using System.Data.SqlClient;

namespace new_distributor
{
    public partial class product : Form
    {
        public product()
        {
            InitializeComponent();
        }
        BAL bl = new BAL();
        SqlDataAdapter ds= new SqlDataAdapter();
        DataTable dt = new DataTable();
        private void insert_Click(object sender, EventArgs e)
        {

         bl.p_insert(product_id.Text, comboBox4.Text, product_name.Text, lbcid.Text, unit_price.Text);
         MessageBox.Show("Successfully saved ");
         comboBox1.Items.Clear();
         category_name.Text = "";
         comboBox4.Items.Clear();
         get_p_name();
        // get_cat_name();
         get_p_type();

         product_id.Text = "";
         product_name.Text = "";
         comboBox4.Text = "";
         category_name.Text = "";
         lbcid.Text = "";
         unit_price.Text = "";
         dataGridView1.DataSource = null;
         
        }

        private void delete_Click(object sender, EventArgs e)
        {
            bl.p_delete(product_id.Text);
            comboBox1.Items.Clear();
            get_p_name();
            MessageBox.Show("Successfully Deleted ");
            product_id.Text = "";
            product_name.Text = "";
            comboBox4.Text = "";
            category_name.Text = "";
            lbcid.Text = "";
            unit_price.Text = "";
            dataGridView1.DataSource = null;
        }

        private void update_Click(object sender, EventArgs e)
        {
            bl.p_update(product_id.Text, comboBox4.Text, product_name.Text, lbcid.Text, unit_price.Text);
            comboBox1.Items.Clear();
            get_p_name();
            MessageBox.Show("Successfully Updated ");
            product_id.Text = "";
            product_name.Text = "";
            comboBox4.Text = "";
            category_name.Text = "";
            lbcid.Text = "";
            unit_price.Text = "";
            dataGridView1.DataSource = null;
        }

        private void search_Click(object sender, EventArgs e)
        {
            dt = bl.p_search(product_id.Text);


            if (dt.Rows.Count >= 1)
            {
                dataGridView1.DataSource = dt;
                
            }
            else
            {


                MessageBox.Show("no data found");
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id;
            id = bl.get_p_id(comboBox1.Text).Rows[0].ItemArray[0].ToString();
            //product_id.Text = id;
                 
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            dt = bl.p_byname(comboBox1.Text);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {

                product_id.Text = dataGridView1.SelectedRows[0].Cells["product_id"].Value.ToString();
                product_name.Text = dataGridView1.SelectedRows[0].Cells["product_name"].Value.ToString();
                comboBox4.Text = dataGridView1.SelectedRows[0].Cells["product_type_name"].Value.ToString();
                lbcid.Text = dataGridView1.SelectedRows[0].Cells["category_id"].Value.ToString();
                unit_price.Text = dataGridView1.SelectedRows[0].Cells["unit_price"].Value.ToString();
              
            }
        }
        private void get_p_type()
        {


            DataTable tb = new DataTable();
            tb = bl.get_type();
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    comboBox4.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                    comboBox5.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                }
            }

        }
        /// <summary>
        /// loading product_id............

        private void loading_product_id()
        {
            dt = bl.product_id();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows.Count > 0)
                {
                    comboBox6.Items.Add(dt.Rows[i].ItemArray[0].ToString());
                }
            }
        }
        private void get_cat_name()
        {

            DataTable tb = new DataTable();
            tb = bl.c_search_name();
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    // comboBox2.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                    comboBox3.Items.Add(tb.Rows[i].ItemArray[0].ToString());

                }
            }

        }
        private void get_p_name()
        {

            DataTable tb = new DataTable();
            tb = bl.p_search_name();
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    comboBox1.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                }
            }

        }
        private void product_Load(object sender, EventArgs e)
        {
            loading_product_id();         
            get_p_name();
            get_cat_name();
            get_p_type();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void producttype_name_TextChanged(object sender, EventArgs e)
        {

        }
       

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
    


        }

        private void category_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
          
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string id;
            //id = bl.get_id(comboBox3.Text).Rows[0].ItemArray[0].ToString();
            //categoryid.Text = id;
        }


        //loading product type name...................

        private void ptinsert_Click(object sender, EventArgs e)
        {
            get_cat_name();
            bl.p_t_insert(protype_name.Text,categoryid.Text);
            get_p_type();
        }

        private void ptdelete_Click(object sender, EventArgs e)
        {
            bl.type_delete(comboBox5.Text);
            get_p_type();
        }

       

        private void ptsearch_Click(object sender, EventArgs e)
        {
           

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            get_cat_id_from_type();
           
        }
        private void get_cat_id_from_type()
        {
           
            dt = bl.get_cat_id_from_type(comboBox4.Text);
          if (dt.Rows.Count > 0)
          {
              lbcid.Text = dt.Rows[0].ItemArray[0].ToString();
          }
        }


        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            dt = bl.type_search(comboBox5.Text);


            if (dt.Rows.Count >= 1)
            {
                dataGridView2.DataSource = dt;
               
            }
            else
            {


                MessageBox.Show("no data found");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //bl.type_update( protype_name.Text, categoryid.Text);
            //comboBox3.Items.Clear();
            //get_p_type();
        }

        private void product_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void category_name_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void lbcid_Click(object sender, EventArgs e)
        {
           
        }
        private void Category_name_search_type()
        {
            DataTable dt = new DataTable();
            dt = bl.c_search_name_type(lbcid.Text);
            if (dt.Rows.Count > 0)
            {
                category_name.Text = dt.Rows[0].ItemArray[0].ToString();

            }  

        }

        private void comboBox4_TabIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void lbcid_TextChanged(object sender, EventArgs e)
        {
            Category_name_search_type();
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}
