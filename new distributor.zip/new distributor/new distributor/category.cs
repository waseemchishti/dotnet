﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using new_distributor.b_l;
using System.Data.SqlClient;

namespace new_distributor
{
    public partial class category : Form
    {
        public category()
        {
            InitializeComponent();
        }
        BAL bl = new BAL();
        //cat insert button..........
      
        private void button1_Click(object sender, EventArgs e)
        {
           /* if (category_id.Text == "")
            {
                MessageBox.Show("No data saved");
                return;
                

            }*/
            DataTable tb = new DataTable();
            tb = bl.category_id_check(category_id.Text);
            if (tb.Rows.Count == 1)
            {
                MessageBox.Show("Please Try another ID", "Error");
                category_id.Text = "";
                category_id.Focus();

            }
            
            //DataTable dt = new DataTable();

            dt = bl.c_insert(category_name.Text, category_des.Text);
            //dataGridView1.DataSource = dt;
            comboBox1.Items.Clear();
            get_cat_name();
             MessageBox.Show("Data Insrted Successfully");

            // category_id.Text = "";
             category_name.Text = "";
             category_des.Text = "";
             get_cat_id();
             get_cat_name();

        }
            
        
                
     
        
        
            //if (dt.Rows.Count >= 1)
            //{
               
                ////category_id.Text = dt.Rows[0]["category_id"].ToString();
                ////category_name.Text = dt.Rows[0]["category_name"].ToString();
                ////category_des.Text = dt.Rows[0]["category_description"].ToString();

                //comboBox1.Text = dt.Rows[0]["category_name"].ToString();
            //    category_id.Text = "";
            //    category_name.Text = "";
            //    category_des.Text = "";
            ////}
            //else
            //{


            //    MessageBox.Show("no data found");
            //}
            
           
         

        //}

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void category_Load(object sender, EventArgs e)
        {
            get_cat_name();
            get_cat_id();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        //category delete button...........
        private void delete_Click(object sender, EventArgs e)
        {
            bl.c_delete(category_id.Text);
            comboBox1.Items.Clear();
            get_cat_name();
            MessageBox.Show("Data Deleted Successfully");
            category_id.Text = "";
        }
        SqlDataAdapter ds = new SqlDataAdapter();
        DataTable dt = new DataTable();

        private void search_Click(object sender, EventArgs e)
        {
           dt= bl.c_search(category_id.Text);


            if (dt.Rows.Count >= 1)
            {
                dataGridView1.DataSource = dt;
                ////category_id.Text = dt.Rows[0]["category_id"].ToString();
                ////category_name.Text = dt.Rows[0]["category_name"].ToString();
                ////category_des.Text = dt.Rows[0]["category_description"].ToString();

                //comboBox1.Text = dt.Rows[0]["category_name"].ToString();
                category_id.Text = "";
                category_name.Text = "";
                category_des.Text = "";
            }
            else {


                MessageBox.Show("no data found");
            }
        }

        private void get_cat_name()
        {
            
            DataTable tb = new DataTable();
            tb = bl.c_search_name();
            if (tb.Rows.Count > 0)
            {

                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    comboBox1.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                }
            }

        }
        private void get_cat_id()
             {
                 DataTable tb = new DataTable();
                 tb = bl.category_id();
                 if (tb.Rows.Count > 0)
                 {

                     for (int i = 0; i < tb.Rows.Count; i++)
                     {
                         comboBox2.Items.Add(tb.Rows[i].ItemArray[0].ToString());
                     }
                 }
              

             }

             private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
             {
                 string id;
                 id = bl.get_id(comboBox1.Text).Rows[0].ItemArray[0].ToString();
                 category_id.Text = id;
                 

             }

             private void update_Click(object sender, EventArgs e)
             {
                 bl.c_update(category_id.Text, category_name.Text, category_des.Text);
                 comboBox1.Items.Clear();
                 get_cat_name();
                 MessageBox.Show("Record Updated");
                 category_id.Text = "";
                 category_name.Text = "";
                 category_des.Text = "";
                 dataGridView1.DataSource = null;
             }

             private void comboBox1_TextChanged(object sender, EventArgs e)
             {
              dt = bl.c_byname(comboBox1.Text);
              dataGridView1.DataSource = dt;

              
             }
                 
             private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
             {

             }

             private void dataGridView1_DoubleClick(object sender, EventArgs e)
             {
                 if (dataGridView1.Rows.Count > 0)
                 {

                     category_id.Text = dataGridView1.SelectedRows[0].Cells["category_id"].Value.ToString();
                     category_name.Text = dataGridView1.SelectedRows[0].Cells["category_name"].Value.ToString();
                     category_des.Text = dataGridView1.SelectedRows[0].Cells["category_description"].Value.ToString();

                 }
             }

             private void category_id_TextChanged(object sender, EventArgs e)
             {
               
              
             }

             private void category_id_CursorChanged(object sender, EventArgs e)
             {
                
             }

             private void category_id_MouseLeave(object sender, EventArgs e)
             {
              
             }

             private void category_id_Leave(object sender, EventArgs e)
             {
                 if(category_id.Text=="")
                 {
                     return;

                 }
                 DataTable tb = new DataTable();
                 tb = bl.category_id_check(category_id.Text);
                 if (tb.Rows.Count == 1)
                 {
                     MessageBox.Show("Please Try another ID", "Error");
                     category_id.Text = "";
                     category_id.Focus();

                 }
             }



        }
    }

